/********************************************************************************
** Form generated from reading UI file 'mainwin.ui'
**
** Created by: Qt User Interface Compiler version 6.2.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWIN_H
#define UI_MAINWIN_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDateEdit>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTableView>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>
#include "qcustomplot.h"

QT_BEGIN_NAMESPACE

class Ui_MainWin
{
public:
    QWidget *centralwidget;
    QHBoxLayout *horizontalLayout;
    QFrame *menu;
    QVBoxLayout *verticalLayout;
    QFrame *logo_block;
    QHBoxLayout *horizontalLayout_2;
    QLabel *logo;
    QLabel *app_name;
    QFrame *menu_button_block;
    QVBoxLayout *verticalLayout_2;
    QPushButton *workforce_button;
    QSpacerItem *verticalSpacer_2;
    QPushButton *employee_button;
    QSpacerItem *verticalSpacer_3;
    QPushButton *website_button;
    QSpacerItem *verticalSpacer_4;
    QPushButton *setting_button;
    QSpacerItem *verticalSpacer_1;
    QLabel *credit_label;
    QFrame *ui_panel;
    QVBoxLayout *verticalLayout_18;
    QFrame *header;
    QHBoxLayout *horizontalLayout_3;
    QFrame *menu_handle;
    QHBoxLayout *horizontalLayout_4;
    QPushButton *m_button;
    QLabel *menu_label;
    QFrame *title_block;
    QVBoxLayout *verticalLayout_12;
    QLabel *ui_title;
    QFrame *navigation;
    QHBoxLayout *horizontalLayout_5;
    QPushButton *hide_button;
    QPushButton *resize_button;
    QPushButton *close_button;
    QStackedWidget *ui_stack;
    QWidget *workforce_ui;
    QGridLayout *gridLayout;
    QFrame *workforce__panel;
    QVBoxLayout *verticalLayout_3;
    QFrame *control_block_1;
    QHBoxLayout *horizontalLayout_8;
    QFrame *category_bleck;
    QVBoxLayout *verticalLayout_17;
    QLabel *category_label;
    QComboBox *category_combo_box;
    QFrame *website_block;
    QVBoxLayout *verticalLayout_16;
    QLabel *website_label;
    QComboBox *website_combo_box;
    QFrame *control_block_2;
    QHBoxLayout *horizontalLayout_9;
    QFrame *start_date_block;
    QVBoxLayout *verticalLayout_14;
    QLabel *start_date_label;
    QDateEdit *start_date_edit;
    QFrame *end_date_blcok;
    QVBoxLayout *verticalLayout_15;
    QLabel *end_date_label;
    QDateEdit *end_date_edit;
    QFrame *plot_control_block;
    QHBoxLayout *horizontalLayout_6;
    QSpacerItem *horizontalSpacer_6;
    QPushButton *database_button;
    QSpacerItem *horizontalSpacer_5;
    QFrame *plot_block;
    QVBoxLayout *verticalLayout_5;
    QStackedWidget *plot_stack;
    QWidget *bar_page;
    QHBoxLayout *horizontalLayout_25;
    QTableView *tableView;
    QFrame *bar_frame;
    QHBoxLayout *horizontalLayout_27;
    QWidget *line_page;
    QVBoxLayout *verticalLayout_9;
    QCustomPlot *line_chart;
    QWidget *pie_page;
    QHBoxLayout *horizontalLayout_28;
    QTableView *pie_chart_table_view;
    QFrame *pie_frame;
    QHBoxLayout *horizontalLayout_29;
    QFrame *plot_button_block;
    QHBoxLayout *horizontalLayout_7;
    QPushButton *bar_chart_button;
    QPushButton *line_chart_button;
    QPushButton *pie_chart_button;
    QWidget *employee_ui;
    QHBoxLayout *horizontalLayout_36;
    QFrame *workforce__panel_2;
    QVBoxLayout *verticalLayout_4;
    QFrame *control_block_3;
    QHBoxLayout *horizontalLayout_12;
    QFrame *emploee_block_2;
    QVBoxLayout *verticalLayout_22;
    QLabel *employee_label_2;
    QComboBox *e_employee_combo_box;
    QFrame *category_bleck_2;
    QVBoxLayout *verticalLayout_23;
    QLabel *category_label_2;
    QComboBox *e_category_combo_box;
    QFrame *website_block_2;
    QVBoxLayout *verticalLayout_24;
    QLabel *website_label_2;
    QComboBox *e_website_combo_box;
    QFrame *control_block_4;
    QHBoxLayout *horizontalLayout_14;
    QFrame *start_date_block_2;
    QVBoxLayout *verticalLayout_39;
    QLabel *start_date_label_2;
    QDateEdit *start_date_edit_2;
    QFrame *end_date_blcok_2;
    QVBoxLayout *verticalLayout_40;
    QLabel *end_date_label_2;
    QDateEdit *end_date_edit_2;
    QFrame *plot_control_block_2;
    QHBoxLayout *horizontalLayout_30;
    QPushButton *go_button;
    QPushButton *upload_button;
    QFrame *e_plot_block;
    QVBoxLayout *verticalLayout_6;
    QStackedWidget *e_plot_stack;
    QWidget *e_bar_page;
    QHBoxLayout *horizontalLayout_31;
    QTableView *e_bar_table_view;
    QFrame *e_bar_frame;
    QHBoxLayout *horizontalLayout_32;
    QWidget *e_line_page;
    QVBoxLayout *verticalLayout_10;
    QCustomPlot *line_chart_2;
    QWidget *e_pie_page;
    QHBoxLayout *horizontalLayout_33;
    QTableView *e_pie_table_view;
    QFrame *pie_frame_2;
    QHBoxLayout *horizontalLayout_34;
    QWidget *e_upload_page;
    QHBoxLayout *horizontalLayout_38;
    QFrame *frame_17;
    QLineEdit *file_name_line_edit;
    QLabel *file_name_label;
    QWidget *layoutWidget;
    QHBoxLayout *horizontalLayout_37;
    QPushButton *browse_button;
    QSpacerItem *horizontalSpacer_7;
    QPushButton *OK_button;
    QFrame *plot_button_block_2;
    QHBoxLayout *horizontalLayout_35;
    QPushButton *e_bar_chart_button;
    QPushButton *e_line_chart_button;
    QPushButton *e_pie_chart_button;
    QWidget *website_ui;
    QGridLayout *gridLayout_4;
    QFrame *workforce__panel_3;
    QVBoxLayout *verticalLayout_25;
    QFrame *plot_window_3;
    QVBoxLayout *verticalLayout_56;
    QFrame *setting_block_2;
    QVBoxLayout *verticalLayout_44;
    QStackedWidget *setting_stack_2;
    QWidget *user_setting_2;
    QHBoxLayout *horizontalLayout_17;
    QFrame *frame_6;
    QVBoxLayout *verticalLayout_20;
    QFrame *frame_10;
    QHBoxLayout *horizontalLayout_18;
    QLabel *label_8;
    QSpacerItem *horizontalSpacer_3;
    QFrame *frame_19;
    QVBoxLayout *verticalLayout_30;
    QVBoxLayout *verticalLayout_28;
    QLabel *label_9;
    QLineEdit *lineEdit_4;
    QSpacerItem *verticalSpacer_18;
    QVBoxLayout *verticalLayout_32;
    QLabel *label_14;
    QComboBox *comboBox;
    QSpacerItem *verticalSpacer_19;
    QFrame *frame_20;
    QHBoxLayout *horizontalLayout_19;
    QPushButton *pushButton_8;
    QSpacerItem *verticalSpacer_7;
    QFrame *frame_21;
    QVBoxLayout *verticalLayout_45;
    QFrame *frame_22;
    QVBoxLayout *verticalLayout_46;
    QLabel *label_20;
    QTableView *user_table_view_2;
    QWidget *category_setting_2;
    QHBoxLayout *horizontalLayout_21;
    QFrame *frame_23;
    QVBoxLayout *verticalLayout_47;
    QFrame *frame_24;
    QHBoxLayout *horizontalLayout_22;
    QLabel *label_21;
    QSpacerItem *horizontalSpacer_4;
    QFrame *frame_25;
    QVBoxLayout *verticalLayout_48;
    QSpacerItem *verticalSpacer_21;
    QVBoxLayout *verticalLayout_49;
    QLabel *label_22;
    QLineEdit *lineEdit_10;
    QSpacerItem *verticalSpacer_22;
    QVBoxLayout *verticalLayout_50;
    QLabel *label_23;
    QLineEdit *lineEdit_11;
    QSpacerItem *verticalSpacer_23;
    QPushButton *pushButton_10;
    QSpacerItem *verticalSpacer_24;
    QFrame *frame_26;
    QVBoxLayout *verticalLayout_51;
    QLabel *label_24;
    QFrame *frame_27;
    QVBoxLayout *verticalLayout_52;
    QSpacerItem *verticalSpacer_25;
    QVBoxLayout *verticalLayout_53;
    QLabel *label_25;
    QLineEdit *lineEdit_12;
    QSpacerItem *verticalSpacer_26;
    QPushButton *pushButton_11;
    QSpacerItem *verticalSpacer_27;
    QFrame *frame_28;
    QVBoxLayout *verticalLayout_54;
    QFrame *frame_29;
    QVBoxLayout *verticalLayout_55;
    QLabel *label_26;
    QTableView *category_table_view_2;
    QFrame *frame_11;
    QHBoxLayout *horizontalLayout_20;
    QWidget *setting_ui;
    QGridLayout *gridLayout_3;
    QFrame *setting_panel;
    QVBoxLayout *verticalLayout_36;
    QFrame *setting_block;
    QVBoxLayout *verticalLayout_43;
    QStackedWidget *setting_stack;
    QWidget *user_setting;
    QHBoxLayout *horizontalLayout_10;
    QFrame *frame;
    QVBoxLayout *verticalLayout_19;
    QFrame *frame_3;
    QHBoxLayout *horizontalLayout_13;
    QLabel *add_new_user_label;
    QSpacerItem *horizontalSpacer;
    QFrame *frame_4;
    QVBoxLayout *verticalLayout_29;
    QVBoxLayout *username_block;
    QLabel *username_label;
    QLineEdit *username_line_edit;
    QSpacerItem *verticalSpacer_8;
    QVBoxLayout *password_block;
    QLabel *password_label;
    QLineEdit *password_line_edit;
    QSpacerItem *verticalSpacer_10;
    QVBoxLayout *real_name_block;
    QLabel *real_name_label;
    QLineEdit *real_name_line_edit;
    QSpacerItem *verticalSpacer_9;
    QGridLayout *admin_super_block;
    QLabel *admin_label;
    QLabel *supervisor_label;
    QCheckBox *admin_check_box;
    QCheckBox *supervisor_check_box;
    QSpacerItem *verticalSpacer_6;
    QFrame *update_user_button_block;
    QHBoxLayout *horizontalLayout_16;
    QPushButton *user_save_button;
    QPushButton *user_update_button;
    QPushButton *user_remove_button;
    QSpacerItem *verticalSpacer;
    QFrame *frame_2;
    QVBoxLayout *verticalLayout_26;
    QFrame *frame_12;
    QVBoxLayout *verticalLayout_27;
    QLabel *user_list_label;
    QFrame *user_list_block;
    QHBoxLayout *horizontalLayout_23;
    QFrame *user_select_block;
    QVBoxLayout *verticalLayout_21;
    QComboBox *user_combo_box;
    QSpacerItem *verticalSpacer_5;
    QSpacerItem *verticalSpacer_20;
    QTableView *user_table_view;
    QWidget *category_setting;
    QHBoxLayout *horizontalLayout_11;
    QFrame *frame_14;
    QVBoxLayout *verticalLayout_34;
    QFrame *frame_15;
    QHBoxLayout *horizontalLayout_15;
    QLabel *label_11;
    QSpacerItem *horizontalSpacer_2;
    QFrame *frame_16;
    QVBoxLayout *verticalLayout_35;
    QSpacerItem *verticalSpacer_12;
    QVBoxLayout *verticalLayout_37;
    QLabel *label_12;
    QLineEdit *lineEdit_5;
    QSpacerItem *verticalSpacer_11;
    QVBoxLayout *verticalLayout_38;
    QLabel *label_13;
    QLineEdit *lineEdit_6;
    QSpacerItem *verticalSpacer_14;
    QFrame *frame_5;
    QHBoxLayout *horizontalLayout_24;
    QPushButton *pushButton_6;
    QPushButton *pushButton_7;
    QSpacerItem *verticalSpacer_15;
    QFrame *frame_18;
    QVBoxLayout *verticalLayout_41;
    QFrame *frame_8;
    QVBoxLayout *verticalLayout_31;
    QFrame *frame_13;
    QVBoxLayout *verticalLayout_33;
    QLabel *label_10;
    QTableView *category_table_view;
    QFrame *setting_button_block;
    QHBoxLayout *horizontalLayout_26;
    QPushButton *user_button;
    QPushButton *category_button;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWin)
    {
        if (MainWin->objectName().isEmpty())
            MainWin->setObjectName(QString::fromUtf8("MainWin"));
        MainWin->resize(1920, 1080);
        MainWin->setStyleSheet(QString::fromUtf8("\n"
"\n"
"/*Copyright (c) DevSec Studio. All rights reserved.\n"
"\n"
"MIT License\n"
"\n"
"Permission is hereby granted, free of charge, to any person obtaining a copy\n"
"of this software and associated documentation files (the \"Software\"), to deal\n"
"in the Software without restriction, including without limitation the rights\n"
"to use, copy, modify, merge, publish, distribute, sublicense, and/or sell\n"
"copies of the Software, and to permit persons to whom the Software is\n"
"furnished to do so, subject to the following conditions:\n"
"\n"
"The above copyright notice and this permission notice shall be included in all\n"
"copies or substantial portions of the Software.\n"
"\n"
"THE SOFTWARE IS PROVIDED *AS IS*, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR\n"
"IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,\n"
"FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE\n"
"AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER\n"
"LIABILITY, WHETHER"
                        " IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,\n"
"OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.\n"
"*/\n"
"\n"
"\n"
"/*-----QWidget-----*/\n"
"QWidget\n"
"{\n"
"	background-color: #ffffff;\n"
"	color: #023E8A;\n"
"\n"
"}\n"
"\n"
"\n"
"/*-----QLabel-----*/\n"
"QLabel\n"
"{\n"
"	background-color: transparent;\n"
"	color: #1D3557;\n"
"	font-weight: bold;\n"
"	font-size: 13px;\n"
"\n"
"}\n"
"\n"
"\n"
"/*-----QPushButton-----*/\n"
"QPushButton\n"
"{\n"
"	background-color: #0077B6;\n"
"	color: #fff;\n"
"	font-size: 13px;\n"
"	font-weight: bold;\n"
"	border-top-right-radius: 15px;\n"
"	border-top-left-radius: 15px;\n"
"	border-bottom-right-radius: 15px;\n"
"	border-bottom-left-radius: 15px;\n"
"	padding: 10px;\n"
"\n"
"}\n"
"\n"
"\n"
"QPushButton::disabled\n"
"{\n"
"	background-color: #5c5c5c;\n"
"\n"
"}\n"
"\n"
"\n"
"QPushButton::hover\n"
"{\n"
"	background-color: #00B4D8;\n"
"\n"
"}\n"
"\n"
"\n"
"QPushButton::pressed\n"
"{\n"
"	background-color: #023E8A;\n"
"\n"
""
                        "}\n"
"\n"
"\n"
"/*-----QCheckBox-----*/\n"
"QCheckBox\n"
"{\n"
"	background-color: transparent;\n"
"	color: #0077B6;\n"
"	font-size: 10px;\n"
"	font-weight: bold;\n"
"	border: none;\n"
"	border-radius: 5px;\n"
"\n"
"}\n"
"\n"
"\n"
"/*-----QCheckBox-----*/\n"
"QCheckBox::indicator\n"
"{\n"
"    background-color: #323232;\n"
"    border: 1px solid darkgray;\n"
"    width: 12px;\n"
"    height: 12px;\n"
"\n"
"}\n"
"\n"
"\n"
"QCheckBox::indicator:checked\n"
"{\n"
"    image:url(\"./ressources/check.png\");\n"
"	background-color: #0077B6;\n"
"    border: 1px solid #0077B6;\n"
"\n"
"}\n"
"\n"
"\n"
"QCheckBox::indicator:unchecked:hover\n"
"{\n"
"    border: 1px solid #0077B6;\n"
"\n"
"}\n"
"\n"
"\n"
"QCheckBox::disabled\n"
"{\n"
"	color: #656565;\n"
"\n"
"}\n"
"\n"
"\n"
"QCheckBox::indicator:disabled\n"
"{\n"
"	background-color: #656565;\n"
"	color: #656565;\n"
"    border: 1px solid #656565;\n"
"\n"
"}\n"
"\n"
"\n"
"/*-----QLineEdit-----*/\n"
"QLineEdit\n"
"{\n"
"	background-color: #c2c7d5;\n"
"	color: #2a547f;\n"
""
                        "	border: none;\n"
"	padding: 5px;\n"
"\n"
"}\n"
"\n"
"\n"
"/*-----QListView-----*/\n"
"QListView\n"
"{\n"
"	background-color: #0077B6;\n"
"	color: #000000;\n"
"	font-size: 14px;\n"
"	font-weight: bold;\n"
"	show-decoration-selected: 0;\n"
"	border-radius: 4px;\n"
"	padding-left: -15px;\n"
"	padding-right: -15px;\n"
"	padding-top: 5px;\n"
"\n"
"} \n"
"\n"
"\n"
"QListView:disabled \n"
"{\n"
"	background-color: #5c5c5c;\n"
"\n"
"}\n"
"\n"
"\n"
"QListView::item\n"
"{\n"
"	background-color: #454e5e;\n"
"	border: none;\n"
"	padding: 10px;\n"
"	border-radius: 0px;\n"
"	padding-left : 10px;\n"
"	height: 32px;\n"
"\n"
"}\n"
"\n"
"\n"
"QListView::item:selected\n"
"{\n"
"	color: #000;\n"
"	background-color: #fff;\n"
"\n"
"}\n"
"\n"
"\n"
"QListView::item:!selected\n"
"{\n"
"	color:#000000;\n"
"	background-color: transparent;\n"
"	border: none;\n"
"	padding-left : 10px;\n"
"\n"
"}\n"
"\n"
"\n"
"QListView::item:!selected:hover\n"
"{\n"
"	color: #000000f;\n"
"	background-color: #00B4D8;\n"
"	border: none;\n"
"	padding-left :"
                        " 10px;\n"
"\n"
"}\n"
"\n"
"\n"
"/*-----QTreeView-----*/\n"
"QTreeView \n"
"{\n"
"	background-color: #fff;\n"
"	show-decoration-selected: 0;\n"
"	color: #1D3557;\n"
"\n"
"}\n"
"\n"
"\n"
"QTreeView:disabled\n"
"{\n"
"	background-color: #242526;\n"
"	show-decoration-selected: 0;\n"
"\n"
"}\n"
"\n"
"\n"
"QTreeView::item \n"
"{\n"
"	border-top-color: transparent;\n"
"	border-bottom-color: transparent;\n"
"\n"
"}\n"
"\n"
"\n"
"QTreeView::item:hover \n"
"{\n"
"	background-color: #bcbdbb;\n"
"	color: #000;\n"
"\n"
"}\n"
"\n"
"\n"
"QTreeView::item:selected \n"
"{\n"
"	background-color: #0077B6;\n"
"	color: #fff;\n"
"\n"
"}\n"
"\n"
"\n"
"QTreeView::item:selected:active\n"
"{\n"
"	background-color: #0077B6;\n"
"	color: #fff;\n"
"\n"
"}\n"
"\n"
"\n"
"QTreeView::item:selected:disabled\n"
"{\n"
"	background-color: #525251;\n"
"	color: #656565;\n"
"\n"
"}\n"
"\n"
"\n"
"QTreeView::branch:has-children:!has-siblings:closed,\n"
"QTreeView::branch:closed:has-children:has-siblings \n"
"{\n"
"	image: url(://tree-closed.png);\n"
"\n"
""
                        "}\n"
"\n"
"QTreeView::branch:open:has-children:!has-siblings,\n"
"QTreeView::branch:open:has-children:has-siblings  \n"
"{\n"
"	image: url(://tree-open.png);\n"
"\n"
"}\n"
"\n"
"\n"
"/*-----QTableView & QTableWidget-----*/\n"
"QTableView\n"
"{\n"
"    background-color: #fff;\n"
"	border: 1px solid gray;\n"
"font-weight: bold;\n"
"    color: #1D3557;\n"
"    gridline-color: gray;\n"
"    outline : 0;\n"
"\n"
"}\n"
"\n"
"\n"
"QTableView::disabled\n"
"{\n"
"    background-color: #242526;\n"
"    border: 1px solid #32414B;\n"
"    color: #656565;\n"
"    gridline-color: #656565;\n"
"    outline : 0;\n"
"\n"
"}\n"
"\n"
"\n"
"QTableView::item:hover \n"
"{\n"
"    background-color: #bcbdbb;\n"
"    color:#000000;\n"
"\n"
"}\n"
"\n"
"\n"
"QTableView::item:selected \n"
"{\n"
"	background-color: #0077B6;\n"
"    color: #000000;\n"
"\n"
"}\n"
"\n"
"\n"
"QTableView::item:selected:disabled\n"
"{\n"
"    background-color: #1a1b1c;\n"
"    border: 2px solid #525251;\n"
"    color: #656565;\n"
"\n"
"}\n"
"\n"
"\n"
"QTableCorn"
                        "erButton::section\n"
"{\n"
"	background-color: #ced5e3;\n"
"	border: none;\n"
"    color:#000000;\n"
"\n"
"}\n"
"\n"
"\n"
"QHeaderView::section\n"
"{\n"
"	color: #2a547f;\n"
"	border: 0px;\n"
"	background-color: #ced5e3;\n"
"	padding: 5px;\n"
"\n"
"}\n"
"\n"
"\n"
"QHeaderView::section:disabled\n"
"{\n"
"    background-color: #525251;\n"
"    color: #656565;\n"
"\n"
"}\n"
"\n"
"\n"
"QHeaderView::section:checked\n"
"{\n"
"    color: #000000;\n"
"    background-color: #0077B6;\n"
"\n"
"}\n"
"\n"
"\n"
"QHeaderView::section:checked:disabled\n"
"{\n"
"    color: #656565;\n"
"    background-color: #525251;\n"
"\n"
"}\n"
"\n"
"\n"
"QHeaderView::section::vertical::first,\n"
"QHeaderView::section::vertical::only-one\n"
"{\n"
"    border-top: 1px solid #353635;\n"
"\n"
"}\n"
"\n"
"\n"
"QHeaderView::section::vertical\n"
"{\n"
"    border-top: 1px solid #353635;\n"
"\n"
"}\n"
"\n"
"\n"
"QHeaderView::section::horizontal::first,\n"
"QHeaderView::section::horizontal::only-one\n"
"{\n"
"    border-left: 1px solid #353635;\n"
""
                        "\n"
"}\n"
"\n"
"\n"
"QHeaderView::section::horizontal\n"
"{\n"
"    border-left: 1px solid #353635;\n"
"\n"
"}\n"
"\n"
"\n"
"/*-----QScrollBar-----*/\n"
"QScrollBar:horizontal \n"
"{\n"
"    background-color: transparent;\n"
"    height: 8px;\n"
"    margin: 0px;\n"
"    padding: 0px;\n"
"\n"
"}\n"
"\n"
"\n"
"QScrollBar::handle:horizontal \n"
"{\n"
"    border: none;\n"
"	min-width: 100px;\n"
"    background-color: #7e92b7;\n"
"\n"
"}\n"
"\n"
"\n"
"QScrollBar::add-line:horizontal, \n"
"QScrollBar::sub-line:horizontal,\n"
"QScrollBar::add-page:horizontal, \n"
"QScrollBar::sub-page:horizontal \n"
"{\n"
"    width: 0px;\n"
"    background-color: #d8dce6;\n"
"\n"
"}\n"
"\n"
"\n"
"QScrollBar:vertical \n"
"{\n"
"    background-color: transparent;\n"
"    width: 8px;\n"
"    margin: 0;\n"
"\n"
"}\n"
"\n"
"\n"
"QScrollBar::handle:vertical \n"
"{\n"
"    border: none;\n"
"	min-height: 100px;\n"
"    background-color: #7e92b7;\n"
"\n"
"}\n"
"\n"
"\n"
"QScrollBar::add-line:vertical, \n"
"QScrollBar::sub-line:vertical,\n"
""
                        "QScrollBar::add-page:vertical, \n"
"QScrollBar::sub-page:vertical \n"
"{\n"
"    height: 0px;\n"
"    background-color: #d8dce6;\n"
"\n"
"}\n"
""));
        centralwidget = new QWidget(MainWin);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        horizontalLayout = new QHBoxLayout(centralwidget);
        horizontalLayout->setSpacing(7);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        menu = new QFrame(centralwidget);
        menu->setObjectName(QString::fromUtf8("menu"));
        menu->setStyleSheet(QString::fromUtf8("QFrame\n"
"{\n"
"	background: #ADE2FF;\n"
"	border-radius: 15px;\n"
"}"));
        menu->setFrameShape(QFrame::StyledPanel);
        menu->setFrameShadow(QFrame::Raised);
        verticalLayout = new QVBoxLayout(menu);
        verticalLayout->setSpacing(0);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        logo_block = new QFrame(menu);
        logo_block->setObjectName(QString::fromUtf8("logo_block"));
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(50);
        sizePolicy.setVerticalStretch(50);
        sizePolicy.setHeightForWidth(logo_block->sizePolicy().hasHeightForWidth());
        logo_block->setSizePolicy(sizePolicy);
        logo_block->setMinimumSize(QSize(0, 100));
        logo_block->setFrameShape(QFrame::StyledPanel);
        logo_block->setFrameShadow(QFrame::Raised);
        horizontalLayout_2 = new QHBoxLayout(logo_block);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        logo = new QLabel(logo_block);
        logo->setObjectName(QString::fromUtf8("logo"));
        QSizePolicy sizePolicy1(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy1.setHorizontalStretch(50);
        sizePolicy1.setVerticalStretch(50);
        sizePolicy1.setHeightForWidth(logo->sizePolicy().hasHeightForWidth());
        logo->setSizePolicy(sizePolicy1);
        logo->setMinimumSize(QSize(50, 50));
        logo->setMaximumSize(QSize(50, 50));
        logo->setPixmap(QPixmap(QString::fromUtf8(":/picture/picture/Aha-Logo.png")));
        logo->setScaledContents(true);

        horizontalLayout_2->addWidget(logo);

        app_name = new QLabel(logo_block);
        app_name->setObjectName(QString::fromUtf8("app_name"));
        QSizePolicy sizePolicy2(QSizePolicy::Fixed, QSizePolicy::Preferred);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(app_name->sizePolicy().hasHeightForWidth());
        app_name->setSizePolicy(sizePolicy2);
        app_name->setMinimumSize(QSize(120, 0));
        QFont font;
        font.setBold(true);
        app_name->setFont(font);
        app_name->setStyleSheet(QString::fromUtf8("QLabel{\n"
"	color: #023E8A;\n"
"}"));
        app_name->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);

        horizontalLayout_2->addWidget(app_name);


        verticalLayout->addWidget(logo_block);

        menu_button_block = new QFrame(menu);
        menu_button_block->setObjectName(QString::fromUtf8("menu_button_block"));
        QSizePolicy sizePolicy3(QSizePolicy::Preferred, QSizePolicy::MinimumExpanding);
        sizePolicy3.setHorizontalStretch(0);
        sizePolicy3.setVerticalStretch(0);
        sizePolicy3.setHeightForWidth(menu_button_block->sizePolicy().hasHeightForWidth());
        menu_button_block->setSizePolicy(sizePolicy3);
        menu_button_block->setStyleSheet(QString::fromUtf8("border-radius: 15px;"));
        menu_button_block->setFrameShape(QFrame::StyledPanel);
        menu_button_block->setFrameShadow(QFrame::Raised);
        verticalLayout_2 = new QVBoxLayout(menu_button_block);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        workforce_button = new QPushButton(menu_button_block);
        workforce_button->setObjectName(QString::fromUtf8("workforce_button"));

        verticalLayout_2->addWidget(workforce_button, 0, Qt::AlignTop);

        verticalSpacer_2 = new QSpacerItem(20, 20, QSizePolicy::Minimum, QSizePolicy::Fixed);

        verticalLayout_2->addItem(verticalSpacer_2);

        employee_button = new QPushButton(menu_button_block);
        employee_button->setObjectName(QString::fromUtf8("employee_button"));

        verticalLayout_2->addWidget(employee_button, 0, Qt::AlignTop);

        verticalSpacer_3 = new QSpacerItem(20, 20, QSizePolicy::Minimum, QSizePolicy::Fixed);

        verticalLayout_2->addItem(verticalSpacer_3);

        website_button = new QPushButton(menu_button_block);
        website_button->setObjectName(QString::fromUtf8("website_button"));

        verticalLayout_2->addWidget(website_button, 0, Qt::AlignTop);

        verticalSpacer_4 = new QSpacerItem(20, 20, QSizePolicy::Minimum, QSizePolicy::Fixed);

        verticalLayout_2->addItem(verticalSpacer_4);

        setting_button = new QPushButton(menu_button_block);
        setting_button->setObjectName(QString::fromUtf8("setting_button"));

        verticalLayout_2->addWidget(setting_button, 0, Qt::AlignTop);

        verticalSpacer_1 = new QSpacerItem(20, 200, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_2->addItem(verticalSpacer_1);

        credit_label = new QLabel(menu_button_block);
        credit_label->setObjectName(QString::fromUtf8("credit_label"));
        credit_label->setAlignment(Qt::AlignCenter);

        verticalLayout_2->addWidget(credit_label, 0, Qt::AlignBottom);


        verticalLayout->addWidget(menu_button_block);


        horizontalLayout->addWidget(menu);

        ui_panel = new QFrame(centralwidget);
        ui_panel->setObjectName(QString::fromUtf8("ui_panel"));
        ui_panel->setStyleSheet(QString::fromUtf8("border-radius: 15px;"));
        ui_panel->setFrameShape(QFrame::StyledPanel);
        ui_panel->setFrameShadow(QFrame::Raised);
        verticalLayout_18 = new QVBoxLayout(ui_panel);
        verticalLayout_18->setSpacing(7);
        verticalLayout_18->setObjectName(QString::fromUtf8("verticalLayout_18"));
        verticalLayout_18->setContentsMargins(0, 0, 0, 0);
        header = new QFrame(ui_panel);
        header->setObjectName(QString::fromUtf8("header"));
        header->setMinimumSize(QSize(0, 80));
        header->setMaximumSize(QSize(16777215, 70));
        header->setStyleSheet(QString::fromUtf8("QFrame\n"
"{\n"
"	background: #0092E0;\n"
"\n"
"}"));
        header->setFrameShape(QFrame::StyledPanel);
        header->setFrameShadow(QFrame::Raised);
        horizontalLayout_3 = new QHBoxLayout(header);
        horizontalLayout_3->setSpacing(0);
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        horizontalLayout_3->setContentsMargins(0, 0, 0, 0);
        menu_handle = new QFrame(header);
        menu_handle->setObjectName(QString::fromUtf8("menu_handle"));
        menu_handle->setMinimumSize(QSize(150, 0));
        menu_handle->setMaximumSize(QSize(40, 16777215));
        menu_handle->setFrameShape(QFrame::StyledPanel);
        menu_handle->setFrameShadow(QFrame::Raised);
        horizontalLayout_4 = new QHBoxLayout(menu_handle);
        horizontalLayout_4->setSpacing(7);
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        horizontalLayout_4->setContentsMargins(11, 11, 11, 11);
        m_button = new QPushButton(menu_handle);
        m_button->setObjectName(QString::fromUtf8("m_button"));
        QSizePolicy sizePolicy4(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy4.setHorizontalStretch(50);
        sizePolicy4.setVerticalStretch(50);
        sizePolicy4.setHeightForWidth(m_button->sizePolicy().hasHeightForWidth());
        m_button->setSizePolicy(sizePolicy4);
        m_button->setMinimumSize(QSize(50, 50));
        m_button->setMaximumSize(QSize(45, 45));
        m_button->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"	background-color: transparent;\n"
"}\n"
"\n"
"QPushButton::hover\n"
"{\n"
"	background-color: #CAF0F8;\n"
"}\n"
""));
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/picture/picture/menu.png"), QSize(), QIcon::Normal, QIcon::Off);
        m_button->setIcon(icon);
        m_button->setIconSize(QSize(40, 40));
        m_button->setAutoDefault(false);

        horizontalLayout_4->addWidget(m_button);

        menu_label = new QLabel(menu_handle);
        menu_label->setObjectName(QString::fromUtf8("menu_label"));

        horizontalLayout_4->addWidget(menu_label);


        horizontalLayout_3->addWidget(menu_handle);

        title_block = new QFrame(header);
        title_block->setObjectName(QString::fromUtf8("title_block"));
        title_block->setFrameShape(QFrame::StyledPanel);
        title_block->setFrameShadow(QFrame::Raised);
        verticalLayout_12 = new QVBoxLayout(title_block);
        verticalLayout_12->setSpacing(0);
        verticalLayout_12->setObjectName(QString::fromUtf8("verticalLayout_12"));
        verticalLayout_12->setContentsMargins(0, 0, 0, 0);
        ui_title = new QLabel(title_block);
        ui_title->setObjectName(QString::fromUtf8("ui_title"));
        ui_title->setAlignment(Qt::AlignCenter);

        verticalLayout_12->addWidget(ui_title);


        horizontalLayout_3->addWidget(title_block);

        navigation = new QFrame(header);
        navigation->setObjectName(QString::fromUtf8("navigation"));
        navigation->setMinimumSize(QSize(150, 0));
        navigation->setMaximumSize(QSize(150, 16777215));
        navigation->setFrameShape(QFrame::StyledPanel);
        navigation->setFrameShadow(QFrame::Raised);
        horizontalLayout_5 = new QHBoxLayout(navigation);
        horizontalLayout_5->setSpacing(0);
        horizontalLayout_5->setObjectName(QString::fromUtf8("horizontalLayout_5"));
        horizontalLayout_5->setContentsMargins(0, 0, 0, 0);
        hide_button = new QPushButton(navigation);
        hide_button->setObjectName(QString::fromUtf8("hide_button"));
        hide_button->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"	background-color: transparent;\n"
"}\n"
"\n"
"QPushButton::hover\n"
"{\n"
"	background-color: #CAF0F8;\n"
"}\n"
""));
        QIcon icon1;
        icon1.addFile(QString::fromUtf8(":/picture/picture/hide.png"), QSize(), QIcon::Normal, QIcon::Off);
        hide_button->setIcon(icon1);
        hide_button->setIconSize(QSize(30, 30));

        horizontalLayout_5->addWidget(hide_button);

        resize_button = new QPushButton(navigation);
        resize_button->setObjectName(QString::fromUtf8("resize_button"));
        resize_button->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"	background-color: transparent;\n"
"}\n"
"\n"
"QPushButton::hover\n"
"{\n"
"	background-color: #CAF0F8;\n"
"}\n"
""));
        QIcon icon2;
        icon2.addFile(QString::fromUtf8(":/picture/picture/resize.png"), QSize(), QIcon::Normal, QIcon::Off);
        resize_button->setIcon(icon2);
        resize_button->setIconSize(QSize(30, 30));
        resize_button->setCheckable(true);

        horizontalLayout_5->addWidget(resize_button);

        close_button = new QPushButton(navigation);
        close_button->setObjectName(QString::fromUtf8("close_button"));
        close_button->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"	background-color: transparent;\n"
"}\n"
"\n"
"QPushButton::hover\n"
"{\n"
"	background-color: #CAF0F8;\n"
"}\n"
""));
        QIcon icon3;
        icon3.addFile(QString::fromUtf8(":/picture/picture/close.png"), QSize(), QIcon::Normal, QIcon::Off);
        close_button->setIcon(icon3);
        close_button->setIconSize(QSize(30, 30));

        horizontalLayout_5->addWidget(close_button);


        horizontalLayout_3->addWidget(navigation);


        verticalLayout_18->addWidget(header, 0, Qt::AlignTop);

        ui_stack = new QStackedWidget(ui_panel);
        ui_stack->setObjectName(QString::fromUtf8("ui_stack"));
        QSizePolicy sizePolicy5(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy5.setHorizontalStretch(0);
        sizePolicy5.setVerticalStretch(0);
        sizePolicy5.setHeightForWidth(ui_stack->sizePolicy().hasHeightForWidth());
        ui_stack->setSizePolicy(sizePolicy5);
        workforce_ui = new QWidget();
        workforce_ui->setObjectName(QString::fromUtf8("workforce_ui"));
        gridLayout = new QGridLayout(workforce_ui);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        gridLayout->setHorizontalSpacing(0);
        gridLayout->setContentsMargins(0, 0, 0, 0);
        workforce__panel = new QFrame(workforce_ui);
        workforce__panel->setObjectName(QString::fromUtf8("workforce__panel"));
        workforce__panel->setFrameShape(QFrame::StyledPanel);
        workforce__panel->setFrameShadow(QFrame::Raised);
        verticalLayout_3 = new QVBoxLayout(workforce__panel);
        verticalLayout_3->setSpacing(0);
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        verticalLayout_3->setContentsMargins(0, 0, 0, 0);
        control_block_1 = new QFrame(workforce__panel);
        control_block_1->setObjectName(QString::fromUtf8("control_block_1"));
        control_block_1->setMinimumSize(QSize(0, 90));
        control_block_1->setMaximumSize(QSize(16777215, 80));
        control_block_1->setStyleSheet(QString::fromUtf8("QFrame\n"
"{\n"
"	background: #D6F1FF;\n"
"   	border-bottom-right-radius:opx;\n"
"	border-bottom-left-radius:opx;\n"
"}"));
        control_block_1->setFrameShape(QFrame::StyledPanel);
        control_block_1->setFrameShadow(QFrame::Raised);
        horizontalLayout_8 = new QHBoxLayout(control_block_1);
        horizontalLayout_8->setSpacing(0);
        horizontalLayout_8->setObjectName(QString::fromUtf8("horizontalLayout_8"));
        horizontalLayout_8->setContentsMargins(0, 0, 0, 0);
        category_bleck = new QFrame(control_block_1);
        category_bleck->setObjectName(QString::fromUtf8("category_bleck"));
        category_bleck->setFrameShape(QFrame::StyledPanel);
        category_bleck->setFrameShadow(QFrame::Raised);
        verticalLayout_17 = new QVBoxLayout(category_bleck);
        verticalLayout_17->setObjectName(QString::fromUtf8("verticalLayout_17"));
        category_label = new QLabel(category_bleck);
        category_label->setObjectName(QString::fromUtf8("category_label"));

        verticalLayout_17->addWidget(category_label);

        category_combo_box = new QComboBox(category_bleck);
        category_combo_box->setObjectName(QString::fromUtf8("category_combo_box"));
        category_combo_box->setMinimumSize(QSize(0, 25));

        verticalLayout_17->addWidget(category_combo_box);


        horizontalLayout_8->addWidget(category_bleck);

        website_block = new QFrame(control_block_1);
        website_block->setObjectName(QString::fromUtf8("website_block"));
        website_block->setFrameShape(QFrame::StyledPanel);
        website_block->setFrameShadow(QFrame::Raised);
        verticalLayout_16 = new QVBoxLayout(website_block);
        verticalLayout_16->setObjectName(QString::fromUtf8("verticalLayout_16"));
        website_label = new QLabel(website_block);
        website_label->setObjectName(QString::fromUtf8("website_label"));

        verticalLayout_16->addWidget(website_label);

        website_combo_box = new QComboBox(website_block);
        website_combo_box->setObjectName(QString::fromUtf8("website_combo_box"));
        website_combo_box->setMinimumSize(QSize(0, 25));

        verticalLayout_16->addWidget(website_combo_box);


        horizontalLayout_8->addWidget(website_block);


        verticalLayout_3->addWidget(control_block_1, 0, Qt::AlignTop);

        control_block_2 = new QFrame(workforce__panel);
        control_block_2->setObjectName(QString::fromUtf8("control_block_2"));
        control_block_2->setMinimumSize(QSize(0, 90));
        control_block_2->setMaximumSize(QSize(16777215, 80));
        control_block_2->setStyleSheet(QString::fromUtf8("QFrame\n"
"{\n"
"	background: #D6F1FF;\n"
"border-radius:opx;\n"
"}"));
        control_block_2->setFrameShape(QFrame::StyledPanel);
        control_block_2->setFrameShadow(QFrame::Raised);
        horizontalLayout_9 = new QHBoxLayout(control_block_2);
        horizontalLayout_9->setSpacing(0);
        horizontalLayout_9->setObjectName(QString::fromUtf8("horizontalLayout_9"));
        horizontalLayout_9->setContentsMargins(0, 0, 0, 0);
        start_date_block = new QFrame(control_block_2);
        start_date_block->setObjectName(QString::fromUtf8("start_date_block"));
        start_date_block->setStyleSheet(QString::fromUtf8("border-radius: 0px;"));
        start_date_block->setFrameShape(QFrame::StyledPanel);
        start_date_block->setFrameShadow(QFrame::Raised);
        verticalLayout_14 = new QVBoxLayout(start_date_block);
        verticalLayout_14->setObjectName(QString::fromUtf8("verticalLayout_14"));
        start_date_label = new QLabel(start_date_block);
        start_date_label->setObjectName(QString::fromUtf8("start_date_label"));

        verticalLayout_14->addWidget(start_date_label);

        start_date_edit = new QDateEdit(start_date_block);
        start_date_edit->setObjectName(QString::fromUtf8("start_date_edit"));
        start_date_edit->setMinimumSize(QSize(0, 25));

        verticalLayout_14->addWidget(start_date_edit);


        horizontalLayout_9->addWidget(start_date_block);

        end_date_blcok = new QFrame(control_block_2);
        end_date_blcok->setObjectName(QString::fromUtf8("end_date_blcok"));
        end_date_blcok->setFrameShape(QFrame::StyledPanel);
        end_date_blcok->setFrameShadow(QFrame::Raised);
        verticalLayout_15 = new QVBoxLayout(end_date_blcok);
        verticalLayout_15->setObjectName(QString::fromUtf8("verticalLayout_15"));
        end_date_label = new QLabel(end_date_blcok);
        end_date_label->setObjectName(QString::fromUtf8("end_date_label"));

        verticalLayout_15->addWidget(end_date_label);

        end_date_edit = new QDateEdit(end_date_blcok);
        end_date_edit->setObjectName(QString::fromUtf8("end_date_edit"));
        end_date_edit->setMinimumSize(QSize(0, 25));

        verticalLayout_15->addWidget(end_date_edit);


        horizontalLayout_9->addWidget(end_date_blcok);

        plot_control_block = new QFrame(control_block_2);
        plot_control_block->setObjectName(QString::fromUtf8("plot_control_block"));
        sizePolicy2.setHeightForWidth(plot_control_block->sizePolicy().hasHeightForWidth());
        plot_control_block->setSizePolicy(sizePolicy2);
        plot_control_block->setMinimumSize(QSize(200, 0));
        plot_control_block->setFrameShape(QFrame::StyledPanel);
        plot_control_block->setFrameShadow(QFrame::Raised);
        horizontalLayout_6 = new QHBoxLayout(plot_control_block);
        horizontalLayout_6->setObjectName(QString::fromUtf8("horizontalLayout_6"));
        horizontalLayout_6->setContentsMargins(0, 0, 0, 0);
        horizontalSpacer_6 = new QSpacerItem(65, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

        horizontalLayout_6->addItem(horizontalSpacer_6);

        database_button = new QPushButton(plot_control_block);
        database_button->setObjectName(QString::fromUtf8("database_button"));
        QIcon icon4;
        icon4.addFile(QString::fromUtf8(":/picture/picture/go.png"), QSize(), QIcon::Normal, QIcon::Off);
        database_button->setIcon(icon4);
        database_button->setIconSize(QSize(30, 30));

        horizontalLayout_6->addWidget(database_button);

        horizontalSpacer_5 = new QSpacerItem(65, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

        horizontalLayout_6->addItem(horizontalSpacer_5);


        horizontalLayout_9->addWidget(plot_control_block);


        verticalLayout_3->addWidget(control_block_2, 0, Qt::AlignTop);

        plot_block = new QFrame(workforce__panel);
        plot_block->setObjectName(QString::fromUtf8("plot_block"));
        sizePolicy5.setHeightForWidth(plot_block->sizePolicy().hasHeightForWidth());
        plot_block->setSizePolicy(sizePolicy5);
        plot_block->setMinimumSize(QSize(0, 0));
        plot_block->setMaximumSize(QSize(16777215, 900));
        plot_block->setStyleSheet(QString::fromUtf8(""));
        plot_block->setFrameShape(QFrame::StyledPanel);
        plot_block->setFrameShadow(QFrame::Raised);
        verticalLayout_5 = new QVBoxLayout(plot_block);
        verticalLayout_5->setSpacing(0);
        verticalLayout_5->setObjectName(QString::fromUtf8("verticalLayout_5"));
        verticalLayout_5->setContentsMargins(0, 0, 0, 0);
        plot_stack = new QStackedWidget(plot_block);
        plot_stack->setObjectName(QString::fromUtf8("plot_stack"));
        bar_page = new QWidget();
        bar_page->setObjectName(QString::fromUtf8("bar_page"));
        horizontalLayout_25 = new QHBoxLayout(bar_page);
        horizontalLayout_25->setObjectName(QString::fromUtf8("horizontalLayout_25"));
        tableView = new QTableView(bar_page);
        tableView->setObjectName(QString::fromUtf8("tableView"));
        QSizePolicy sizePolicy6(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy6.setHorizontalStretch(0);
        sizePolicy6.setVerticalStretch(0);
        sizePolicy6.setHeightForWidth(tableView->sizePolicy().hasHeightForWidth());
        tableView->setSizePolicy(sizePolicy6);

        horizontalLayout_25->addWidget(tableView);

        bar_frame = new QFrame(bar_page);
        bar_frame->setObjectName(QString::fromUtf8("bar_frame"));
        horizontalLayout_27 = new QHBoxLayout(bar_frame);
        horizontalLayout_27->setObjectName(QString::fromUtf8("horizontalLayout_27"));

        horizontalLayout_25->addWidget(bar_frame);

        plot_stack->addWidget(bar_page);
        line_page = new QWidget();
        line_page->setObjectName(QString::fromUtf8("line_page"));
        verticalLayout_9 = new QVBoxLayout(line_page);
        verticalLayout_9->setObjectName(QString::fromUtf8("verticalLayout_9"));
        line_chart = new QCustomPlot(line_page);
        line_chart->setObjectName(QString::fromUtf8("line_chart"));

        verticalLayout_9->addWidget(line_chart);

        plot_stack->addWidget(line_page);
        pie_page = new QWidget();
        pie_page->setObjectName(QString::fromUtf8("pie_page"));
        horizontalLayout_28 = new QHBoxLayout(pie_page);
        horizontalLayout_28->setObjectName(QString::fromUtf8("horizontalLayout_28"));
        pie_chart_table_view = new QTableView(pie_page);
        pie_chart_table_view->setObjectName(QString::fromUtf8("pie_chart_table_view"));
        sizePolicy6.setHeightForWidth(pie_chart_table_view->sizePolicy().hasHeightForWidth());
        pie_chart_table_view->setSizePolicy(sizePolicy6);

        horizontalLayout_28->addWidget(pie_chart_table_view);

        pie_frame = new QFrame(pie_page);
        pie_frame->setObjectName(QString::fromUtf8("pie_frame"));
        horizontalLayout_29 = new QHBoxLayout(pie_frame);
        horizontalLayout_29->setObjectName(QString::fromUtf8("horizontalLayout_29"));

        horizontalLayout_28->addWidget(pie_frame);

        plot_stack->addWidget(pie_page);

        verticalLayout_5->addWidget(plot_stack);


        verticalLayout_3->addWidget(plot_block);

        plot_button_block = new QFrame(workforce__panel);
        plot_button_block->setObjectName(QString::fromUtf8("plot_button_block"));
        plot_button_block->setMinimumSize(QSize(0, 80));
        plot_button_block->setMaximumSize(QSize(16777215, 80));
        plot_button_block->setStyleSheet(QString::fromUtf8("QFrame{\n"
"	background: #D6F1FF;\n"
"   	border-top-right-radius:opx;\n"
"	border-top-left-radius:opx;\n"
"}"));
        plot_button_block->setFrameShape(QFrame::StyledPanel);
        plot_button_block->setFrameShadow(QFrame::Raised);
        horizontalLayout_7 = new QHBoxLayout(plot_button_block);
        horizontalLayout_7->setObjectName(QString::fromUtf8("horizontalLayout_7"));
        bar_chart_button = new QPushButton(plot_button_block);
        bar_chart_button->setObjectName(QString::fromUtf8("bar_chart_button"));
        QIcon icon5;
        icon5.addFile(QString::fromUtf8(":/picture/picture/bar-chart.png"), QSize(), QIcon::Normal, QIcon::Off);
        bar_chart_button->setIcon(icon5);
        bar_chart_button->setIconSize(QSize(30, 30));

        horizontalLayout_7->addWidget(bar_chart_button);

        line_chart_button = new QPushButton(plot_button_block);
        line_chart_button->setObjectName(QString::fromUtf8("line_chart_button"));
        QIcon icon6;
        icon6.addFile(QString::fromUtf8(":/picture/picture/line-chart.png"), QSize(), QIcon::Normal, QIcon::Off);
        line_chart_button->setIcon(icon6);
        line_chart_button->setIconSize(QSize(30, 30));

        horizontalLayout_7->addWidget(line_chart_button);

        pie_chart_button = new QPushButton(plot_button_block);
        pie_chart_button->setObjectName(QString::fromUtf8("pie_chart_button"));
        QIcon icon7;
        icon7.addFile(QString::fromUtf8(":/picture/picture/pie_chart.png"), QSize(), QIcon::Normal, QIcon::Off);
        pie_chart_button->setIcon(icon7);
        pie_chart_button->setIconSize(QSize(30, 30));

        horizontalLayout_7->addWidget(pie_chart_button);


        verticalLayout_3->addWidget(plot_button_block, 0, Qt::AlignBottom);


        gridLayout->addWidget(workforce__panel, 0, 0, 1, 1);

        ui_stack->addWidget(workforce_ui);
        employee_ui = new QWidget();
        employee_ui->setObjectName(QString::fromUtf8("employee_ui"));
        horizontalLayout_36 = new QHBoxLayout(employee_ui);
        horizontalLayout_36->setObjectName(QString::fromUtf8("horizontalLayout_36"));
        horizontalLayout_36->setContentsMargins(0, 0, 0, 0);
        workforce__panel_2 = new QFrame(employee_ui);
        workforce__panel_2->setObjectName(QString::fromUtf8("workforce__panel_2"));
        workforce__panel_2->setFrameShape(QFrame::StyledPanel);
        workforce__panel_2->setFrameShadow(QFrame::Raised);
        verticalLayout_4 = new QVBoxLayout(workforce__panel_2);
        verticalLayout_4->setSpacing(0);
        verticalLayout_4->setObjectName(QString::fromUtf8("verticalLayout_4"));
        verticalLayout_4->setContentsMargins(0, 0, 0, 0);
        control_block_3 = new QFrame(workforce__panel_2);
        control_block_3->setObjectName(QString::fromUtf8("control_block_3"));
        control_block_3->setMinimumSize(QSize(0, 90));
        control_block_3->setMaximumSize(QSize(16777215, 80));
        control_block_3->setStyleSheet(QString::fromUtf8("QFrame\n"
"{\n"
"	background: #D6F1FF;\n"
"   	border-bottom-right-radius:opx;\n"
"	border-bottom-left-radius:opx;\n"
"}"));
        control_block_3->setFrameShape(QFrame::StyledPanel);
        control_block_3->setFrameShadow(QFrame::Raised);
        horizontalLayout_12 = new QHBoxLayout(control_block_3);
        horizontalLayout_12->setSpacing(0);
        horizontalLayout_12->setObjectName(QString::fromUtf8("horizontalLayout_12"));
        horizontalLayout_12->setContentsMargins(0, 0, 0, 0);
        emploee_block_2 = new QFrame(control_block_3);
        emploee_block_2->setObjectName(QString::fromUtf8("emploee_block_2"));
        emploee_block_2->setFrameShape(QFrame::StyledPanel);
        emploee_block_2->setFrameShadow(QFrame::Raised);
        verticalLayout_22 = new QVBoxLayout(emploee_block_2);
        verticalLayout_22->setSpacing(0);
        verticalLayout_22->setObjectName(QString::fromUtf8("verticalLayout_22"));
        employee_label_2 = new QLabel(emploee_block_2);
        employee_label_2->setObjectName(QString::fromUtf8("employee_label_2"));

        verticalLayout_22->addWidget(employee_label_2);

        e_employee_combo_box = new QComboBox(emploee_block_2);
        e_employee_combo_box->setObjectName(QString::fromUtf8("e_employee_combo_box"));
        e_employee_combo_box->setMinimumSize(QSize(0, 25));

        verticalLayout_22->addWidget(e_employee_combo_box);


        horizontalLayout_12->addWidget(emploee_block_2);

        category_bleck_2 = new QFrame(control_block_3);
        category_bleck_2->setObjectName(QString::fromUtf8("category_bleck_2"));
        category_bleck_2->setFrameShape(QFrame::StyledPanel);
        category_bleck_2->setFrameShadow(QFrame::Raised);
        verticalLayout_23 = new QVBoxLayout(category_bleck_2);
        verticalLayout_23->setObjectName(QString::fromUtf8("verticalLayout_23"));
        category_label_2 = new QLabel(category_bleck_2);
        category_label_2->setObjectName(QString::fromUtf8("category_label_2"));

        verticalLayout_23->addWidget(category_label_2);

        e_category_combo_box = new QComboBox(category_bleck_2);
        e_category_combo_box->setObjectName(QString::fromUtf8("e_category_combo_box"));
        e_category_combo_box->setMinimumSize(QSize(0, 25));

        verticalLayout_23->addWidget(e_category_combo_box);


        horizontalLayout_12->addWidget(category_bleck_2);

        website_block_2 = new QFrame(control_block_3);
        website_block_2->setObjectName(QString::fromUtf8("website_block_2"));
        website_block_2->setFrameShape(QFrame::StyledPanel);
        website_block_2->setFrameShadow(QFrame::Raised);
        verticalLayout_24 = new QVBoxLayout(website_block_2);
        verticalLayout_24->setObjectName(QString::fromUtf8("verticalLayout_24"));
        website_label_2 = new QLabel(website_block_2);
        website_label_2->setObjectName(QString::fromUtf8("website_label_2"));

        verticalLayout_24->addWidget(website_label_2);

        e_website_combo_box = new QComboBox(website_block_2);
        e_website_combo_box->setObjectName(QString::fromUtf8("e_website_combo_box"));
        e_website_combo_box->setMinimumSize(QSize(0, 25));

        verticalLayout_24->addWidget(e_website_combo_box);


        horizontalLayout_12->addWidget(website_block_2);


        verticalLayout_4->addWidget(control_block_3, 0, Qt::AlignTop);

        control_block_4 = new QFrame(workforce__panel_2);
        control_block_4->setObjectName(QString::fromUtf8("control_block_4"));
        control_block_4->setMinimumSize(QSize(0, 90));
        control_block_4->setMaximumSize(QSize(16777215, 80));
        control_block_4->setStyleSheet(QString::fromUtf8("QFrame\n"
"{\n"
"	background: #D6F1FF;\n"
"border-radius:opx;\n"
"}"));
        control_block_4->setFrameShape(QFrame::StyledPanel);
        control_block_4->setFrameShadow(QFrame::Raised);
        horizontalLayout_14 = new QHBoxLayout(control_block_4);
        horizontalLayout_14->setSpacing(0);
        horizontalLayout_14->setObjectName(QString::fromUtf8("horizontalLayout_14"));
        horizontalLayout_14->setContentsMargins(0, 0, 0, 0);
        start_date_block_2 = new QFrame(control_block_4);
        start_date_block_2->setObjectName(QString::fromUtf8("start_date_block_2"));
        start_date_block_2->setStyleSheet(QString::fromUtf8("border-radius: 0px;"));
        start_date_block_2->setFrameShape(QFrame::StyledPanel);
        start_date_block_2->setFrameShadow(QFrame::Raised);
        verticalLayout_39 = new QVBoxLayout(start_date_block_2);
        verticalLayout_39->setObjectName(QString::fromUtf8("verticalLayout_39"));
        start_date_label_2 = new QLabel(start_date_block_2);
        start_date_label_2->setObjectName(QString::fromUtf8("start_date_label_2"));

        verticalLayout_39->addWidget(start_date_label_2);

        start_date_edit_2 = new QDateEdit(start_date_block_2);
        start_date_edit_2->setObjectName(QString::fromUtf8("start_date_edit_2"));
        start_date_edit_2->setMinimumSize(QSize(0, 25));

        verticalLayout_39->addWidget(start_date_edit_2);


        horizontalLayout_14->addWidget(start_date_block_2);

        end_date_blcok_2 = new QFrame(control_block_4);
        end_date_blcok_2->setObjectName(QString::fromUtf8("end_date_blcok_2"));
        end_date_blcok_2->setFrameShape(QFrame::StyledPanel);
        end_date_blcok_2->setFrameShadow(QFrame::Raised);
        verticalLayout_40 = new QVBoxLayout(end_date_blcok_2);
        verticalLayout_40->setObjectName(QString::fromUtf8("verticalLayout_40"));
        end_date_label_2 = new QLabel(end_date_blcok_2);
        end_date_label_2->setObjectName(QString::fromUtf8("end_date_label_2"));

        verticalLayout_40->addWidget(end_date_label_2);

        end_date_edit_2 = new QDateEdit(end_date_blcok_2);
        end_date_edit_2->setObjectName(QString::fromUtf8("end_date_edit_2"));
        end_date_edit_2->setMinimumSize(QSize(0, 25));

        verticalLayout_40->addWidget(end_date_edit_2);


        horizontalLayout_14->addWidget(end_date_blcok_2);

        plot_control_block_2 = new QFrame(control_block_4);
        plot_control_block_2->setObjectName(QString::fromUtf8("plot_control_block_2"));
        sizePolicy2.setHeightForWidth(plot_control_block_2->sizePolicy().hasHeightForWidth());
        plot_control_block_2->setSizePolicy(sizePolicy2);
        plot_control_block_2->setMinimumSize(QSize(200, 0));
        plot_control_block_2->setFrameShape(QFrame::StyledPanel);
        plot_control_block_2->setFrameShadow(QFrame::Raised);
        horizontalLayout_30 = new QHBoxLayout(plot_control_block_2);
        horizontalLayout_30->setObjectName(QString::fromUtf8("horizontalLayout_30"));
        horizontalLayout_30->setContentsMargins(0, 0, 0, 0);
        go_button = new QPushButton(plot_control_block_2);
        go_button->setObjectName(QString::fromUtf8("go_button"));
        QIcon icon8;
        icon8.addFile(QString::fromUtf8("picture/go.png"), QSize(), QIcon::Normal, QIcon::Off);
        go_button->setIcon(icon8);
        go_button->setIconSize(QSize(30, 30));

        horizontalLayout_30->addWidget(go_button);

        upload_button = new QPushButton(plot_control_block_2);
        upload_button->setObjectName(QString::fromUtf8("upload_button"));
        QIcon icon9;
        icon9.addFile(QString::fromUtf8(":/picture/picture/load.png"), QSize(), QIcon::Normal, QIcon::Off);
        upload_button->setIcon(icon9);
        upload_button->setIconSize(QSize(30, 30));

        horizontalLayout_30->addWidget(upload_button);


        horizontalLayout_14->addWidget(plot_control_block_2);


        verticalLayout_4->addWidget(control_block_4, 0, Qt::AlignTop);

        e_plot_block = new QFrame(workforce__panel_2);
        e_plot_block->setObjectName(QString::fromUtf8("e_plot_block"));
        sizePolicy5.setHeightForWidth(e_plot_block->sizePolicy().hasHeightForWidth());
        e_plot_block->setSizePolicy(sizePolicy5);
        e_plot_block->setMinimumSize(QSize(0, 0));
        e_plot_block->setMaximumSize(QSize(16777215, 900));
        e_plot_block->setStyleSheet(QString::fromUtf8(""));
        e_plot_block->setFrameShape(QFrame::StyledPanel);
        e_plot_block->setFrameShadow(QFrame::Raised);
        verticalLayout_6 = new QVBoxLayout(e_plot_block);
        verticalLayout_6->setSpacing(0);
        verticalLayout_6->setObjectName(QString::fromUtf8("verticalLayout_6"));
        verticalLayout_6->setContentsMargins(0, 0, 0, 0);
        e_plot_stack = new QStackedWidget(e_plot_block);
        e_plot_stack->setObjectName(QString::fromUtf8("e_plot_stack"));
        e_bar_page = new QWidget();
        e_bar_page->setObjectName(QString::fromUtf8("e_bar_page"));
        horizontalLayout_31 = new QHBoxLayout(e_bar_page);
        horizontalLayout_31->setObjectName(QString::fromUtf8("horizontalLayout_31"));
        e_bar_table_view = new QTableView(e_bar_page);
        e_bar_table_view->setObjectName(QString::fromUtf8("e_bar_table_view"));
        sizePolicy6.setHeightForWidth(e_bar_table_view->sizePolicy().hasHeightForWidth());
        e_bar_table_view->setSizePolicy(sizePolicy6);

        horizontalLayout_31->addWidget(e_bar_table_view);

        e_bar_frame = new QFrame(e_bar_page);
        e_bar_frame->setObjectName(QString::fromUtf8("e_bar_frame"));
        horizontalLayout_32 = new QHBoxLayout(e_bar_frame);
        horizontalLayout_32->setObjectName(QString::fromUtf8("horizontalLayout_32"));

        horizontalLayout_31->addWidget(e_bar_frame);

        e_plot_stack->addWidget(e_bar_page);
        e_line_page = new QWidget();
        e_line_page->setObjectName(QString::fromUtf8("e_line_page"));
        verticalLayout_10 = new QVBoxLayout(e_line_page);
        verticalLayout_10->setObjectName(QString::fromUtf8("verticalLayout_10"));
        line_chart_2 = new QCustomPlot(e_line_page);
        line_chart_2->setObjectName(QString::fromUtf8("line_chart_2"));

        verticalLayout_10->addWidget(line_chart_2);

        e_plot_stack->addWidget(e_line_page);
        e_pie_page = new QWidget();
        e_pie_page->setObjectName(QString::fromUtf8("e_pie_page"));
        horizontalLayout_33 = new QHBoxLayout(e_pie_page);
        horizontalLayout_33->setObjectName(QString::fromUtf8("horizontalLayout_33"));
        e_pie_table_view = new QTableView(e_pie_page);
        e_pie_table_view->setObjectName(QString::fromUtf8("e_pie_table_view"));
        sizePolicy6.setHeightForWidth(e_pie_table_view->sizePolicy().hasHeightForWidth());
        e_pie_table_view->setSizePolicy(sizePolicy6);

        horizontalLayout_33->addWidget(e_pie_table_view);

        pie_frame_2 = new QFrame(e_pie_page);
        pie_frame_2->setObjectName(QString::fromUtf8("pie_frame_2"));
        horizontalLayout_34 = new QHBoxLayout(pie_frame_2);
        horizontalLayout_34->setObjectName(QString::fromUtf8("horizontalLayout_34"));

        horizontalLayout_33->addWidget(pie_frame_2);

        e_plot_stack->addWidget(e_pie_page);
        e_upload_page = new QWidget();
        e_upload_page->setObjectName(QString::fromUtf8("e_upload_page"));
        horizontalLayout_38 = new QHBoxLayout(e_upload_page);
        horizontalLayout_38->setObjectName(QString::fromUtf8("horizontalLayout_38"));
        frame_17 = new QFrame(e_upload_page);
        frame_17->setObjectName(QString::fromUtf8("frame_17"));
        sizePolicy5.setHeightForWidth(frame_17->sizePolicy().hasHeightForWidth());
        frame_17->setSizePolicy(sizePolicy5);
        frame_17->setFrameShape(QFrame::StyledPanel);
        frame_17->setFrameShadow(QFrame::Raised);
        file_name_line_edit = new QLineEdit(frame_17);
        file_name_line_edit->setObjectName(QString::fromUtf8("file_name_line_edit"));
        file_name_line_edit->setGeometry(QRect(490, 244, 911, 31));
        file_name_label = new QLabel(frame_17);
        file_name_label->setObjectName(QString::fromUtf8("file_name_label"));
        file_name_label->setGeometry(QRect(490, 210, 81, 19));
        layoutWidget = new QWidget(frame_17);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(730, 380, 421, 38));
        horizontalLayout_37 = new QHBoxLayout(layoutWidget);
        horizontalLayout_37->setObjectName(QString::fromUtf8("horizontalLayout_37"));
        horizontalLayout_37->setContentsMargins(0, 0, 0, 0);
        browse_button = new QPushButton(layoutWidget);
        browse_button->setObjectName(QString::fromUtf8("browse_button"));

        horizontalLayout_37->addWidget(browse_button);

        horizontalSpacer_7 = new QSpacerItem(60, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

        horizontalLayout_37->addItem(horizontalSpacer_7);

        OK_button = new QPushButton(layoutWidget);
        OK_button->setObjectName(QString::fromUtf8("OK_button"));

        horizontalLayout_37->addWidget(OK_button);


        horizontalLayout_38->addWidget(frame_17);

        e_plot_stack->addWidget(e_upload_page);

        verticalLayout_6->addWidget(e_plot_stack);


        verticalLayout_4->addWidget(e_plot_block);

        plot_button_block_2 = new QFrame(workforce__panel_2);
        plot_button_block_2->setObjectName(QString::fromUtf8("plot_button_block_2"));
        plot_button_block_2->setMinimumSize(QSize(0, 80));
        plot_button_block_2->setMaximumSize(QSize(16777215, 80));
        plot_button_block_2->setStyleSheet(QString::fromUtf8("QFrame{\n"
"	background: #D6F1FF;\n"
"   	border-top-right-radius:opx;\n"
"	border-top-left-radius:opx;\n"
"}"));
        plot_button_block_2->setFrameShape(QFrame::StyledPanel);
        plot_button_block_2->setFrameShadow(QFrame::Raised);
        horizontalLayout_35 = new QHBoxLayout(plot_button_block_2);
        horizontalLayout_35->setObjectName(QString::fromUtf8("horizontalLayout_35"));
        e_bar_chart_button = new QPushButton(plot_button_block_2);
        e_bar_chart_button->setObjectName(QString::fromUtf8("e_bar_chart_button"));
        e_bar_chart_button->setIcon(icon5);
        e_bar_chart_button->setIconSize(QSize(30, 30));

        horizontalLayout_35->addWidget(e_bar_chart_button);

        e_line_chart_button = new QPushButton(plot_button_block_2);
        e_line_chart_button->setObjectName(QString::fromUtf8("e_line_chart_button"));
        e_line_chart_button->setIcon(icon6);
        e_line_chart_button->setIconSize(QSize(30, 30));

        horizontalLayout_35->addWidget(e_line_chart_button);

        e_pie_chart_button = new QPushButton(plot_button_block_2);
        e_pie_chart_button->setObjectName(QString::fromUtf8("e_pie_chart_button"));
        e_pie_chart_button->setIcon(icon7);
        e_pie_chart_button->setIconSize(QSize(30, 30));

        horizontalLayout_35->addWidget(e_pie_chart_button);


        verticalLayout_4->addWidget(plot_button_block_2, 0, Qt::AlignBottom);


        horizontalLayout_36->addWidget(workforce__panel_2);

        ui_stack->addWidget(employee_ui);
        website_ui = new QWidget();
        website_ui->setObjectName(QString::fromUtf8("website_ui"));
        gridLayout_4 = new QGridLayout(website_ui);
        gridLayout_4->setObjectName(QString::fromUtf8("gridLayout_4"));
        gridLayout_4->setHorizontalSpacing(0);
        gridLayout_4->setContentsMargins(0, 0, 0, 0);
        workforce__panel_3 = new QFrame(website_ui);
        workforce__panel_3->setObjectName(QString::fromUtf8("workforce__panel_3"));
        workforce__panel_3->setFrameShape(QFrame::StyledPanel);
        workforce__panel_3->setFrameShadow(QFrame::Raised);
        verticalLayout_25 = new QVBoxLayout(workforce__panel_3);
        verticalLayout_25->setSpacing(0);
        verticalLayout_25->setObjectName(QString::fromUtf8("verticalLayout_25"));
        verticalLayout_25->setContentsMargins(0, 0, 0, 0);
        plot_window_3 = new QFrame(workforce__panel_3);
        plot_window_3->setObjectName(QString::fromUtf8("plot_window_3"));
        sizePolicy5.setHeightForWidth(plot_window_3->sizePolicy().hasHeightForWidth());
        plot_window_3->setSizePolicy(sizePolicy5);
        plot_window_3->setMinimumSize(QSize(0, 0));
        plot_window_3->setMaximumSize(QSize(16777215, 900));
        plot_window_3->setStyleSheet(QString::fromUtf8(""));
        plot_window_3->setFrameShape(QFrame::StyledPanel);
        plot_window_3->setFrameShadow(QFrame::Raised);
        verticalLayout_56 = new QVBoxLayout(plot_window_3);
        verticalLayout_56->setObjectName(QString::fromUtf8("verticalLayout_56"));
        setting_block_2 = new QFrame(plot_window_3);
        setting_block_2->setObjectName(QString::fromUtf8("setting_block_2"));
        sizePolicy5.setHeightForWidth(setting_block_2->sizePolicy().hasHeightForWidth());
        setting_block_2->setSizePolicy(sizePolicy5);
        setting_block_2->setMinimumSize(QSize(0, 0));
        setting_block_2->setMaximumSize(QSize(16777215, 900));
        setting_block_2->setStyleSheet(QString::fromUtf8(""));
        setting_block_2->setFrameShape(QFrame::StyledPanel);
        setting_block_2->setFrameShadow(QFrame::Raised);
        verticalLayout_44 = new QVBoxLayout(setting_block_2);
        verticalLayout_44->setSpacing(0);
        verticalLayout_44->setObjectName(QString::fromUtf8("verticalLayout_44"));
        verticalLayout_44->setContentsMargins(0, 0, 0, 0);
        setting_stack_2 = new QStackedWidget(setting_block_2);
        setting_stack_2->setObjectName(QString::fromUtf8("setting_stack_2"));
        user_setting_2 = new QWidget();
        user_setting_2->setObjectName(QString::fromUtf8("user_setting_2"));
        horizontalLayout_17 = new QHBoxLayout(user_setting_2);
        horizontalLayout_17->setObjectName(QString::fromUtf8("horizontalLayout_17"));
        frame_6 = new QFrame(user_setting_2);
        frame_6->setObjectName(QString::fromUtf8("frame_6"));
        QSizePolicy sizePolicy7(QSizePolicy::Fixed, QSizePolicy::Minimum);
        sizePolicy7.setHorizontalStretch(0);
        sizePolicy7.setVerticalStretch(0);
        sizePolicy7.setHeightForWidth(frame_6->sizePolicy().hasHeightForWidth());
        frame_6->setSizePolicy(sizePolicy7);
        frame_6->setFrameShape(QFrame::StyledPanel);
        frame_6->setFrameShadow(QFrame::Raised);
        verticalLayout_20 = new QVBoxLayout(frame_6);
        verticalLayout_20->setObjectName(QString::fromUtf8("verticalLayout_20"));
        frame_10 = new QFrame(frame_6);
        frame_10->setObjectName(QString::fromUtf8("frame_10"));
        QSizePolicy sizePolicy8(QSizePolicy::Minimum, QSizePolicy::Minimum);
        sizePolicy8.setHorizontalStretch(0);
        sizePolicy8.setVerticalStretch(0);
        sizePolicy8.setHeightForWidth(frame_10->sizePolicy().hasHeightForWidth());
        frame_10->setSizePolicy(sizePolicy8);
        frame_10->setStyleSheet(QString::fromUtf8("QFrame\n"
"{\n"
"	background: #ADE2FF;\n"
"	border-radius: 15px;\n"
"}"));
        frame_10->setFrameShape(QFrame::StyledPanel);
        frame_10->setFrameShadow(QFrame::Raised);
        horizontalLayout_18 = new QHBoxLayout(frame_10);
        horizontalLayout_18->setObjectName(QString::fromUtf8("horizontalLayout_18"));
        label_8 = new QLabel(frame_10);
        label_8->setObjectName(QString::fromUtf8("label_8"));
        QSizePolicy sizePolicy9(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy9.setHorizontalStretch(0);
        sizePolicy9.setVerticalStretch(0);
        sizePolicy9.setHeightForWidth(label_8->sizePolicy().hasHeightForWidth());
        label_8->setSizePolicy(sizePolicy9);

        horizontalLayout_18->addWidget(label_8);

        horizontalSpacer_3 = new QSpacerItem(400, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

        horizontalLayout_18->addItem(horizontalSpacer_3);


        verticalLayout_20->addWidget(frame_10);

        frame_19 = new QFrame(frame_6);
        frame_19->setObjectName(QString::fromUtf8("frame_19"));
        sizePolicy5.setHeightForWidth(frame_19->sizePolicy().hasHeightForWidth());
        frame_19->setSizePolicy(sizePolicy5);
        frame_19->setFrameShape(QFrame::StyledPanel);
        frame_19->setFrameShadow(QFrame::Raised);
        verticalLayout_30 = new QVBoxLayout(frame_19);
        verticalLayout_30->setObjectName(QString::fromUtf8("verticalLayout_30"));
        verticalLayout_30->setContentsMargins(0, -1, -1, -1);
        verticalLayout_28 = new QVBoxLayout();
        verticalLayout_28->setSpacing(0);
        verticalLayout_28->setObjectName(QString::fromUtf8("verticalLayout_28"));
        label_9 = new QLabel(frame_19);
        label_9->setObjectName(QString::fromUtf8("label_9"));
        QSizePolicy sizePolicy10(QSizePolicy::Preferred, QSizePolicy::Fixed);
        sizePolicy10.setHorizontalStretch(0);
        sizePolicy10.setVerticalStretch(0);
        sizePolicy10.setHeightForWidth(label_9->sizePolicy().hasHeightForWidth());
        label_9->setSizePolicy(sizePolicy10);

        verticalLayout_28->addWidget(label_9, 0, Qt::AlignTop);

        lineEdit_4 = new QLineEdit(frame_19);
        lineEdit_4->setObjectName(QString::fromUtf8("lineEdit_4"));
        QSizePolicy sizePolicy11(QSizePolicy::Expanding, QSizePolicy::Fixed);
        sizePolicy11.setHorizontalStretch(0);
        sizePolicy11.setVerticalStretch(0);
        sizePolicy11.setHeightForWidth(lineEdit_4->sizePolicy().hasHeightForWidth());
        lineEdit_4->setSizePolicy(sizePolicy11);
        lineEdit_4->setStyleSheet(QString::fromUtf8("	border-top-right-radius: 10px;\n"
"	border-top-left-radius:10px;\n"
"	border-bottom-right-radius: 10px;\n"
"	border-bottom-left-radius:10px;"));

        verticalLayout_28->addWidget(lineEdit_4);


        verticalLayout_30->addLayout(verticalLayout_28);

        verticalSpacer_18 = new QSpacerItem(20, 20, QSizePolicy::Minimum, QSizePolicy::Fixed);

        verticalLayout_30->addItem(verticalSpacer_18);

        verticalLayout_32 = new QVBoxLayout();
        verticalLayout_32->setSpacing(0);
        verticalLayout_32->setObjectName(QString::fromUtf8("verticalLayout_32"));
        label_14 = new QLabel(frame_19);
        label_14->setObjectName(QString::fromUtf8("label_14"));
        sizePolicy10.setHeightForWidth(label_14->sizePolicy().hasHeightForWidth());
        label_14->setSizePolicy(sizePolicy10);

        verticalLayout_32->addWidget(label_14, 0, Qt::AlignTop);

        comboBox = new QComboBox(frame_19);
        comboBox->setObjectName(QString::fromUtf8("comboBox"));
        comboBox->setMinimumSize(QSize(0, 30));

        verticalLayout_32->addWidget(comboBox);


        verticalLayout_30->addLayout(verticalLayout_32);

        verticalSpacer_19 = new QSpacerItem(20, 10, QSizePolicy::Minimum, QSizePolicy::Fixed);

        verticalLayout_30->addItem(verticalSpacer_19);

        frame_20 = new QFrame(frame_19);
        frame_20->setObjectName(QString::fromUtf8("frame_20"));
        frame_20->setFrameShape(QFrame::StyledPanel);
        frame_20->setFrameShadow(QFrame::Raised);
        horizontalLayout_19 = new QHBoxLayout(frame_20);
        horizontalLayout_19->setObjectName(QString::fromUtf8("horizontalLayout_19"));
        pushButton_8 = new QPushButton(frame_20);
        pushButton_8->setObjectName(QString::fromUtf8("pushButton_8"));
        pushButton_8->setFont(font);

        horizontalLayout_19->addWidget(pushButton_8);


        verticalLayout_30->addWidget(frame_20);

        verticalSpacer_7 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_30->addItem(verticalSpacer_7);


        verticalLayout_20->addWidget(frame_19);


        horizontalLayout_17->addWidget(frame_6);

        frame_21 = new QFrame(user_setting_2);
        frame_21->setObjectName(QString::fromUtf8("frame_21"));
        frame_21->setFrameShape(QFrame::StyledPanel);
        frame_21->setFrameShadow(QFrame::Raised);
        verticalLayout_45 = new QVBoxLayout(frame_21);
        verticalLayout_45->setObjectName(QString::fromUtf8("verticalLayout_45"));
        frame_22 = new QFrame(frame_21);
        frame_22->setObjectName(QString::fromUtf8("frame_22"));
        frame_22->setStyleSheet(QString::fromUtf8("QFrame\n"
"{\n"
"	background: #ADE2FF;\n"
"	border-radius: 15px;\n"
"}"));
        frame_22->setFrameShape(QFrame::StyledPanel);
        frame_22->setFrameShadow(QFrame::Raised);
        verticalLayout_46 = new QVBoxLayout(frame_22);
        verticalLayout_46->setObjectName(QString::fromUtf8("verticalLayout_46"));
        label_20 = new QLabel(frame_22);
        label_20->setObjectName(QString::fromUtf8("label_20"));

        verticalLayout_46->addWidget(label_20);


        verticalLayout_45->addWidget(frame_22);

        user_table_view_2 = new QTableView(frame_21);
        user_table_view_2->setObjectName(QString::fromUtf8("user_table_view_2"));
        QSizePolicy sizePolicy12(QSizePolicy::Preferred, QSizePolicy::Expanding);
        sizePolicy12.setHorizontalStretch(0);
        sizePolicy12.setVerticalStretch(0);
        sizePolicy12.setHeightForWidth(user_table_view_2->sizePolicy().hasHeightForWidth());
        user_table_view_2->setSizePolicy(sizePolicy12);

        verticalLayout_45->addWidget(user_table_view_2);


        horizontalLayout_17->addWidget(frame_21);

        setting_stack_2->addWidget(user_setting_2);
        category_setting_2 = new QWidget();
        category_setting_2->setObjectName(QString::fromUtf8("category_setting_2"));
        horizontalLayout_21 = new QHBoxLayout(category_setting_2);
        horizontalLayout_21->setObjectName(QString::fromUtf8("horizontalLayout_21"));
        frame_23 = new QFrame(category_setting_2);
        frame_23->setObjectName(QString::fromUtf8("frame_23"));
        sizePolicy7.setHeightForWidth(frame_23->sizePolicy().hasHeightForWidth());
        frame_23->setSizePolicy(sizePolicy7);
        frame_23->setFrameShape(QFrame::StyledPanel);
        frame_23->setFrameShadow(QFrame::Raised);
        verticalLayout_47 = new QVBoxLayout(frame_23);
        verticalLayout_47->setObjectName(QString::fromUtf8("verticalLayout_47"));
        verticalLayout_47->setContentsMargins(0, 0, 0, 0);
        frame_24 = new QFrame(frame_23);
        frame_24->setObjectName(QString::fromUtf8("frame_24"));
        sizePolicy8.setHeightForWidth(frame_24->sizePolicy().hasHeightForWidth());
        frame_24->setSizePolicy(sizePolicy8);
        frame_24->setStyleSheet(QString::fromUtf8("QFrame\n"
"{\n"
"	background: #ADE2FF;\n"
"	border-radius: 15px;\n"
"}"));
        frame_24->setFrameShape(QFrame::StyledPanel);
        frame_24->setFrameShadow(QFrame::Raised);
        horizontalLayout_22 = new QHBoxLayout(frame_24);
        horizontalLayout_22->setObjectName(QString::fromUtf8("horizontalLayout_22"));
        label_21 = new QLabel(frame_24);
        label_21->setObjectName(QString::fromUtf8("label_21"));
        sizePolicy9.setHeightForWidth(label_21->sizePolicy().hasHeightForWidth());
        label_21->setSizePolicy(sizePolicy9);

        horizontalLayout_22->addWidget(label_21);

        horizontalSpacer_4 = new QSpacerItem(400, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

        horizontalLayout_22->addItem(horizontalSpacer_4);


        verticalLayout_47->addWidget(frame_24);

        frame_25 = new QFrame(frame_23);
        frame_25->setObjectName(QString::fromUtf8("frame_25"));
        sizePolicy5.setHeightForWidth(frame_25->sizePolicy().hasHeightForWidth());
        frame_25->setSizePolicy(sizePolicy5);
        frame_25->setFrameShape(QFrame::StyledPanel);
        frame_25->setFrameShadow(QFrame::Raised);
        verticalLayout_48 = new QVBoxLayout(frame_25);
        verticalLayout_48->setObjectName(QString::fromUtf8("verticalLayout_48"));
        verticalLayout_48->setContentsMargins(0, -1, -1, -1);
        verticalSpacer_21 = new QSpacerItem(20, 10, QSizePolicy::Minimum, QSizePolicy::Fixed);

        verticalLayout_48->addItem(verticalSpacer_21);

        verticalLayout_49 = new QVBoxLayout();
        verticalLayout_49->setSpacing(0);
        verticalLayout_49->setObjectName(QString::fromUtf8("verticalLayout_49"));
        label_22 = new QLabel(frame_25);
        label_22->setObjectName(QString::fromUtf8("label_22"));
        sizePolicy10.setHeightForWidth(label_22->sizePolicy().hasHeightForWidth());
        label_22->setSizePolicy(sizePolicy10);

        verticalLayout_49->addWidget(label_22, 0, Qt::AlignTop);

        lineEdit_10 = new QLineEdit(frame_25);
        lineEdit_10->setObjectName(QString::fromUtf8("lineEdit_10"));
        sizePolicy11.setHeightForWidth(lineEdit_10->sizePolicy().hasHeightForWidth());
        lineEdit_10->setSizePolicy(sizePolicy11);
        lineEdit_10->setStyleSheet(QString::fromUtf8("	border-top-right-radius: 10px;\n"
"	border-top-left-radius:10px;\n"
"	border-bottom-right-radius: 10px;\n"
"	border-bottom-left-radius:10px;"));

        verticalLayout_49->addWidget(lineEdit_10);


        verticalLayout_48->addLayout(verticalLayout_49);

        verticalSpacer_22 = new QSpacerItem(20, 20, QSizePolicy::Minimum, QSizePolicy::Fixed);

        verticalLayout_48->addItem(verticalSpacer_22);

        verticalLayout_50 = new QVBoxLayout();
        verticalLayout_50->setSpacing(0);
        verticalLayout_50->setObjectName(QString::fromUtf8("verticalLayout_50"));
        label_23 = new QLabel(frame_25);
        label_23->setObjectName(QString::fromUtf8("label_23"));
        sizePolicy10.setHeightForWidth(label_23->sizePolicy().hasHeightForWidth());
        label_23->setSizePolicy(sizePolicy10);

        verticalLayout_50->addWidget(label_23, 0, Qt::AlignTop);

        lineEdit_11 = new QLineEdit(frame_25);
        lineEdit_11->setObjectName(QString::fromUtf8("lineEdit_11"));
        lineEdit_11->setStyleSheet(QString::fromUtf8("	border-top-right-radius: 10px;\n"
"	border-top-left-radius:10px;\n"
"	border-bottom-right-radius: 10px;\n"
"	border-bottom-left-radius:10px;"));

        verticalLayout_50->addWidget(lineEdit_11);


        verticalLayout_48->addLayout(verticalLayout_50);

        verticalSpacer_23 = new QSpacerItem(20, 20, QSizePolicy::Minimum, QSizePolicy::Fixed);

        verticalLayout_48->addItem(verticalSpacer_23);

        pushButton_10 = new QPushButton(frame_25);
        pushButton_10->setObjectName(QString::fromUtf8("pushButton_10"));
        pushButton_10->setFont(font);

        verticalLayout_48->addWidget(pushButton_10);

        verticalSpacer_24 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_48->addItem(verticalSpacer_24);


        verticalLayout_47->addWidget(frame_25);

        frame_26 = new QFrame(frame_23);
        frame_26->setObjectName(QString::fromUtf8("frame_26"));
        frame_26->setStyleSheet(QString::fromUtf8("QFrame\n"
"{\n"
"	background: #ADE2FF;\n"
"	border-radius: 15px;\n"
"}"));
        frame_26->setFrameShape(QFrame::StyledPanel);
        frame_26->setFrameShadow(QFrame::Raised);
        verticalLayout_51 = new QVBoxLayout(frame_26);
        verticalLayout_51->setObjectName(QString::fromUtf8("verticalLayout_51"));
        label_24 = new QLabel(frame_26);
        label_24->setObjectName(QString::fromUtf8("label_24"));
        sizePolicy9.setHeightForWidth(label_24->sizePolicy().hasHeightForWidth());
        label_24->setSizePolicy(sizePolicy9);

        verticalLayout_51->addWidget(label_24);


        verticalLayout_47->addWidget(frame_26);

        frame_27 = new QFrame(frame_23);
        frame_27->setObjectName(QString::fromUtf8("frame_27"));
        sizePolicy6.setHeightForWidth(frame_27->sizePolicy().hasHeightForWidth());
        frame_27->setSizePolicy(sizePolicy6);
        frame_27->setFrameShape(QFrame::StyledPanel);
        frame_27->setFrameShadow(QFrame::Raised);
        verticalLayout_52 = new QVBoxLayout(frame_27);
        verticalLayout_52->setObjectName(QString::fromUtf8("verticalLayout_52"));
        verticalLayout_52->setContentsMargins(0, -1, -1, -1);
        verticalSpacer_25 = new QSpacerItem(20, 10, QSizePolicy::Minimum, QSizePolicy::Fixed);

        verticalLayout_52->addItem(verticalSpacer_25);

        verticalLayout_53 = new QVBoxLayout();
        verticalLayout_53->setObjectName(QString::fromUtf8("verticalLayout_53"));
        label_25 = new QLabel(frame_27);
        label_25->setObjectName(QString::fromUtf8("label_25"));
        sizePolicy10.setHeightForWidth(label_25->sizePolicy().hasHeightForWidth());
        label_25->setSizePolicy(sizePolicy10);

        verticalLayout_53->addWidget(label_25);

        lineEdit_12 = new QLineEdit(frame_27);
        lineEdit_12->setObjectName(QString::fromUtf8("lineEdit_12"));
        sizePolicy11.setHeightForWidth(lineEdit_12->sizePolicy().hasHeightForWidth());
        lineEdit_12->setSizePolicy(sizePolicy11);
        lineEdit_12->setStyleSheet(QString::fromUtf8("	border-top-right-radius: 10px;\n"
"	border-top-left-radius:10px;\n"
"	border-bottom-right-radius: 10px;\n"
"	border-bottom-left-radius:10px;"));

        verticalLayout_53->addWidget(lineEdit_12);


        verticalLayout_52->addLayout(verticalLayout_53);

        verticalSpacer_26 = new QSpacerItem(20, 20, QSizePolicy::Minimum, QSizePolicy::Fixed);

        verticalLayout_52->addItem(verticalSpacer_26);

        pushButton_11 = new QPushButton(frame_27);
        pushButton_11->setObjectName(QString::fromUtf8("pushButton_11"));

        verticalLayout_52->addWidget(pushButton_11);

        verticalSpacer_27 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_52->addItem(verticalSpacer_27);


        verticalLayout_47->addWidget(frame_27);


        horizontalLayout_21->addWidget(frame_23);

        frame_28 = new QFrame(category_setting_2);
        frame_28->setObjectName(QString::fromUtf8("frame_28"));
        frame_28->setFrameShape(QFrame::StyledPanel);
        frame_28->setFrameShadow(QFrame::Raised);
        verticalLayout_54 = new QVBoxLayout(frame_28);
        verticalLayout_54->setObjectName(QString::fromUtf8("verticalLayout_54"));
        verticalLayout_54->setContentsMargins(0, 0, 0, 0);
        frame_29 = new QFrame(frame_28);
        frame_29->setObjectName(QString::fromUtf8("frame_29"));
        frame_29->setStyleSheet(QString::fromUtf8("QFrame\n"
"{\n"
"	background: #ADE2FF;\n"
"	border-radius: 15px;\n"
"}"));
        frame_29->setFrameShape(QFrame::StyledPanel);
        frame_29->setFrameShadow(QFrame::Raised);
        verticalLayout_55 = new QVBoxLayout(frame_29);
        verticalLayout_55->setObjectName(QString::fromUtf8("verticalLayout_55"));
        label_26 = new QLabel(frame_29);
        label_26->setObjectName(QString::fromUtf8("label_26"));

        verticalLayout_55->addWidget(label_26);


        verticalLayout_54->addWidget(frame_29);

        category_table_view_2 = new QTableView(frame_28);
        category_table_view_2->setObjectName(QString::fromUtf8("category_table_view_2"));
        sizePolicy12.setHeightForWidth(category_table_view_2->sizePolicy().hasHeightForWidth());
        category_table_view_2->setSizePolicy(sizePolicy12);

        verticalLayout_54->addWidget(category_table_view_2);


        horizontalLayout_21->addWidget(frame_28);

        setting_stack_2->addWidget(category_setting_2);

        verticalLayout_44->addWidget(setting_stack_2);


        verticalLayout_56->addWidget(setting_block_2);


        verticalLayout_25->addWidget(plot_window_3);

        frame_11 = new QFrame(workforce__panel_3);
        frame_11->setObjectName(QString::fromUtf8("frame_11"));
        frame_11->setMinimumSize(QSize(0, 80));
        frame_11->setMaximumSize(QSize(16777215, 80));
        frame_11->setFrameShape(QFrame::StyledPanel);
        frame_11->setFrameShadow(QFrame::Raised);
        horizontalLayout_20 = new QHBoxLayout(frame_11);
        horizontalLayout_20->setObjectName(QString::fromUtf8("horizontalLayout_20"));

        verticalLayout_25->addWidget(frame_11);


        gridLayout_4->addWidget(workforce__panel_3, 0, 0, 1, 1);

        ui_stack->addWidget(website_ui);
        setting_ui = new QWidget();
        setting_ui->setObjectName(QString::fromUtf8("setting_ui"));
        gridLayout_3 = new QGridLayout(setting_ui);
        gridLayout_3->setObjectName(QString::fromUtf8("gridLayout_3"));
        gridLayout_3->setHorizontalSpacing(0);
        gridLayout_3->setContentsMargins(0, 0, 0, 0);
        setting_panel = new QFrame(setting_ui);
        setting_panel->setObjectName(QString::fromUtf8("setting_panel"));
        setting_panel->setFrameShape(QFrame::StyledPanel);
        setting_panel->setFrameShadow(QFrame::Raised);
        verticalLayout_36 = new QVBoxLayout(setting_panel);
        verticalLayout_36->setSpacing(0);
        verticalLayout_36->setObjectName(QString::fromUtf8("verticalLayout_36"));
        verticalLayout_36->setContentsMargins(0, 0, 0, 0);
        setting_block = new QFrame(setting_panel);
        setting_block->setObjectName(QString::fromUtf8("setting_block"));
        sizePolicy5.setHeightForWidth(setting_block->sizePolicy().hasHeightForWidth());
        setting_block->setSizePolicy(sizePolicy5);
        setting_block->setMinimumSize(QSize(0, 0));
        setting_block->setMaximumSize(QSize(16777215, 900));
        setting_block->setStyleSheet(QString::fromUtf8(""));
        setting_block->setFrameShape(QFrame::StyledPanel);
        setting_block->setFrameShadow(QFrame::Raised);
        verticalLayout_43 = new QVBoxLayout(setting_block);
        verticalLayout_43->setSpacing(0);
        verticalLayout_43->setObjectName(QString::fromUtf8("verticalLayout_43"));
        verticalLayout_43->setContentsMargins(0, 0, 0, 0);
        setting_stack = new QStackedWidget(setting_block);
        setting_stack->setObjectName(QString::fromUtf8("setting_stack"));
        user_setting = new QWidget();
        user_setting->setObjectName(QString::fromUtf8("user_setting"));
        horizontalLayout_10 = new QHBoxLayout(user_setting);
        horizontalLayout_10->setObjectName(QString::fromUtf8("horizontalLayout_10"));
        frame = new QFrame(user_setting);
        frame->setObjectName(QString::fromUtf8("frame"));
        sizePolicy7.setHeightForWidth(frame->sizePolicy().hasHeightForWidth());
        frame->setSizePolicy(sizePolicy7);
        frame->setFrameShape(QFrame::StyledPanel);
        frame->setFrameShadow(QFrame::Raised);
        verticalLayout_19 = new QVBoxLayout(frame);
        verticalLayout_19->setObjectName(QString::fromUtf8("verticalLayout_19"));
        frame_3 = new QFrame(frame);
        frame_3->setObjectName(QString::fromUtf8("frame_3"));
        sizePolicy8.setHeightForWidth(frame_3->sizePolicy().hasHeightForWidth());
        frame_3->setSizePolicy(sizePolicy8);
        frame_3->setStyleSheet(QString::fromUtf8("QFrame\n"
"{\n"
"	background: #ADE2FF;\n"
"	border-radius: 15px;\n"
"}"));
        frame_3->setFrameShape(QFrame::StyledPanel);
        frame_3->setFrameShadow(QFrame::Raised);
        horizontalLayout_13 = new QHBoxLayout(frame_3);
        horizontalLayout_13->setObjectName(QString::fromUtf8("horizontalLayout_13"));
        add_new_user_label = new QLabel(frame_3);
        add_new_user_label->setObjectName(QString::fromUtf8("add_new_user_label"));
        sizePolicy9.setHeightForWidth(add_new_user_label->sizePolicy().hasHeightForWidth());
        add_new_user_label->setSizePolicy(sizePolicy9);

        horizontalLayout_13->addWidget(add_new_user_label);

        horizontalSpacer = new QSpacerItem(400, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

        horizontalLayout_13->addItem(horizontalSpacer);


        verticalLayout_19->addWidget(frame_3);

        frame_4 = new QFrame(frame);
        frame_4->setObjectName(QString::fromUtf8("frame_4"));
        sizePolicy5.setHeightForWidth(frame_4->sizePolicy().hasHeightForWidth());
        frame_4->setSizePolicy(sizePolicy5);
        frame_4->setFrameShape(QFrame::StyledPanel);
        frame_4->setFrameShadow(QFrame::Raised);
        verticalLayout_29 = new QVBoxLayout(frame_4);
        verticalLayout_29->setObjectName(QString::fromUtf8("verticalLayout_29"));
        username_block = new QVBoxLayout();
        username_block->setSpacing(0);
        username_block->setObjectName(QString::fromUtf8("username_block"));
        username_label = new QLabel(frame_4);
        username_label->setObjectName(QString::fromUtf8("username_label"));
        sizePolicy10.setHeightForWidth(username_label->sizePolicy().hasHeightForWidth());
        username_label->setSizePolicy(sizePolicy10);

        username_block->addWidget(username_label, 0, Qt::AlignTop);

        username_line_edit = new QLineEdit(frame_4);
        username_line_edit->setObjectName(QString::fromUtf8("username_line_edit"));
        sizePolicy11.setHeightForWidth(username_line_edit->sizePolicy().hasHeightForWidth());
        username_line_edit->setSizePolicy(sizePolicy11);
        username_line_edit->setStyleSheet(QString::fromUtf8("	border-top-right-radius: 10px;\n"
"	border-top-left-radius:10px;\n"
"	border-bottom-right-radius: 10px;\n"
"	border-bottom-left-radius:10px;"));

        username_block->addWidget(username_line_edit);


        verticalLayout_29->addLayout(username_block);

        verticalSpacer_8 = new QSpacerItem(20, 20, QSizePolicy::Minimum, QSizePolicy::Fixed);

        verticalLayout_29->addItem(verticalSpacer_8);

        password_block = new QVBoxLayout();
        password_block->setSpacing(0);
        password_block->setObjectName(QString::fromUtf8("password_block"));
        password_label = new QLabel(frame_4);
        password_label->setObjectName(QString::fromUtf8("password_label"));
        sizePolicy10.setHeightForWidth(password_label->sizePolicy().hasHeightForWidth());
        password_label->setSizePolicy(sizePolicy10);

        password_block->addWidget(password_label, 0, Qt::AlignTop);

        password_line_edit = new QLineEdit(frame_4);
        password_line_edit->setObjectName(QString::fromUtf8("password_line_edit"));
        password_line_edit->setStyleSheet(QString::fromUtf8("	border-top-right-radius: 10px;\n"
"	border-top-left-radius:10px;\n"
"	border-bottom-right-radius: 10px;\n"
"	border-bottom-left-radius:10px;"));

        password_block->addWidget(password_line_edit);


        verticalLayout_29->addLayout(password_block);

        verticalSpacer_10 = new QSpacerItem(20, 20, QSizePolicy::Minimum, QSizePolicy::Fixed);

        verticalLayout_29->addItem(verticalSpacer_10);

        real_name_block = new QVBoxLayout();
        real_name_block->setSpacing(0);
        real_name_block->setObjectName(QString::fromUtf8("real_name_block"));
        real_name_label = new QLabel(frame_4);
        real_name_label->setObjectName(QString::fromUtf8("real_name_label"));
        sizePolicy10.setHeightForWidth(real_name_label->sizePolicy().hasHeightForWidth());
        real_name_label->setSizePolicy(sizePolicy10);

        real_name_block->addWidget(real_name_label);

        real_name_line_edit = new QLineEdit(frame_4);
        real_name_line_edit->setObjectName(QString::fromUtf8("real_name_line_edit"));
        real_name_line_edit->setStyleSheet(QString::fromUtf8("	border-top-right-radius: 10px;\n"
"	border-top-left-radius:10px;\n"
"	border-bottom-right-radius: 10px;\n"
"	border-bottom-left-radius:10px;"));

        real_name_block->addWidget(real_name_line_edit);


        verticalLayout_29->addLayout(real_name_block);

        verticalSpacer_9 = new QSpacerItem(20, 20, QSizePolicy::Minimum, QSizePolicy::Fixed);

        verticalLayout_29->addItem(verticalSpacer_9);

        admin_super_block = new QGridLayout();
        admin_super_block->setObjectName(QString::fromUtf8("admin_super_block"));
        admin_label = new QLabel(frame_4);
        admin_label->setObjectName(QString::fromUtf8("admin_label"));
        sizePolicy10.setHeightForWidth(admin_label->sizePolicy().hasHeightForWidth());
        admin_label->setSizePolicy(sizePolicy10);

        admin_super_block->addWidget(admin_label, 0, 0, 1, 1);

        supervisor_label = new QLabel(frame_4);
        supervisor_label->setObjectName(QString::fromUtf8("supervisor_label"));
        sizePolicy10.setHeightForWidth(supervisor_label->sizePolicy().hasHeightForWidth());
        supervisor_label->setSizePolicy(sizePolicy10);

        admin_super_block->addWidget(supervisor_label, 0, 1, 1, 1);

        admin_check_box = new QCheckBox(frame_4);
        admin_check_box->setObjectName(QString::fromUtf8("admin_check_box"));
        sizePolicy8.setHeightForWidth(admin_check_box->sizePolicy().hasHeightForWidth());
        admin_check_box->setSizePolicy(sizePolicy8);
        admin_check_box->setStyleSheet(QString::fromUtf8("QCheckBox::indicator {\n"
"     width: 25px;\n"
"     height: 25px;\n"
"	border-top-right-radius: 10px;\n"
"	border-top-left-radius:10px;\n"
"	border-bottom-right-radius: 10px;\n"
"	border-bottom-left-radius:10px;\n"
" }"));

        admin_super_block->addWidget(admin_check_box, 1, 0, 1, 1);

        supervisor_check_box = new QCheckBox(frame_4);
        supervisor_check_box->setObjectName(QString::fromUtf8("supervisor_check_box"));
        QSizePolicy sizePolicy13(QSizePolicy::Minimum, QSizePolicy::Fixed);
        sizePolicy13.setHorizontalStretch(0);
        sizePolicy13.setVerticalStretch(0);
        sizePolicy13.setHeightForWidth(supervisor_check_box->sizePolicy().hasHeightForWidth());
        supervisor_check_box->setSizePolicy(sizePolicy13);
        supervisor_check_box->setMinimumSize(QSize(30, 30));
        supervisor_check_box->setStyleSheet(QString::fromUtf8("QCheckBox::indicator {\n"
"     width: 25px;\n"
"     height: 25px;\n"
"	border-top-right-radius: 10px;\n"
"	border-top-left-radius:10px;\n"
"	border-bottom-right-radius: 10px;\n"
"	border-bottom-left-radius:10px;\n"
" }"));
        supervisor_check_box->setIconSize(QSize(20, 20));

        admin_super_block->addWidget(supervisor_check_box, 1, 1, 1, 1);


        verticalLayout_29->addLayout(admin_super_block);

        verticalSpacer_6 = new QSpacerItem(20, 20, QSizePolicy::Minimum, QSizePolicy::Fixed);

        verticalLayout_29->addItem(verticalSpacer_6);

        update_user_button_block = new QFrame(frame_4);
        update_user_button_block->setObjectName(QString::fromUtf8("update_user_button_block"));
        update_user_button_block->setFrameShape(QFrame::StyledPanel);
        update_user_button_block->setFrameShadow(QFrame::Raised);
        horizontalLayout_16 = new QHBoxLayout(update_user_button_block);
        horizontalLayout_16->setObjectName(QString::fromUtf8("horizontalLayout_16"));
        user_save_button = new QPushButton(update_user_button_block);
        user_save_button->setObjectName(QString::fromUtf8("user_save_button"));
        user_save_button->setFont(font);

        horizontalLayout_16->addWidget(user_save_button);

        user_update_button = new QPushButton(update_user_button_block);
        user_update_button->setObjectName(QString::fromUtf8("user_update_button"));

        horizontalLayout_16->addWidget(user_update_button);

        user_remove_button = new QPushButton(update_user_button_block);
        user_remove_button->setObjectName(QString::fromUtf8("user_remove_button"));

        horizontalLayout_16->addWidget(user_remove_button);


        verticalLayout_29->addWidget(update_user_button_block);


        verticalLayout_19->addWidget(frame_4);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_19->addItem(verticalSpacer);


        horizontalLayout_10->addWidget(frame);

        frame_2 = new QFrame(user_setting);
        frame_2->setObjectName(QString::fromUtf8("frame_2"));
        frame_2->setFrameShape(QFrame::StyledPanel);
        frame_2->setFrameShadow(QFrame::Raised);
        verticalLayout_26 = new QVBoxLayout(frame_2);
        verticalLayout_26->setObjectName(QString::fromUtf8("verticalLayout_26"));
        frame_12 = new QFrame(frame_2);
        frame_12->setObjectName(QString::fromUtf8("frame_12"));
        frame_12->setStyleSheet(QString::fromUtf8("QFrame\n"
"{\n"
"	background: #ADE2FF;\n"
"	border-radius: 15px;\n"
"}"));
        frame_12->setFrameShape(QFrame::StyledPanel);
        frame_12->setFrameShadow(QFrame::Raised);
        verticalLayout_27 = new QVBoxLayout(frame_12);
        verticalLayout_27->setObjectName(QString::fromUtf8("verticalLayout_27"));
        user_list_label = new QLabel(frame_12);
        user_list_label->setObjectName(QString::fromUtf8("user_list_label"));

        verticalLayout_27->addWidget(user_list_label);


        verticalLayout_26->addWidget(frame_12);

        user_list_block = new QFrame(frame_2);
        user_list_block->setObjectName(QString::fromUtf8("user_list_block"));
        user_list_block->setFrameShape(QFrame::StyledPanel);
        user_list_block->setFrameShadow(QFrame::Raised);
        horizontalLayout_23 = new QHBoxLayout(user_list_block);
        horizontalLayout_23->setObjectName(QString::fromUtf8("horizontalLayout_23"));
        user_select_block = new QFrame(user_list_block);
        user_select_block->setObjectName(QString::fromUtf8("user_select_block"));
        QSizePolicy sizePolicy14(QSizePolicy::Maximum, QSizePolicy::Preferred);
        sizePolicy14.setHorizontalStretch(0);
        sizePolicy14.setVerticalStretch(0);
        sizePolicy14.setHeightForWidth(user_select_block->sizePolicy().hasHeightForWidth());
        user_select_block->setSizePolicy(sizePolicy14);
        user_select_block->setFrameShape(QFrame::StyledPanel);
        user_select_block->setFrameShadow(QFrame::Raised);
        verticalLayout_21 = new QVBoxLayout(user_select_block);
        verticalLayout_21->setObjectName(QString::fromUtf8("verticalLayout_21"));
        verticalLayout_21->setContentsMargins(0, 0, 0, 0);
        user_combo_box = new QComboBox(user_select_block);
        user_combo_box->setObjectName(QString::fromUtf8("user_combo_box"));
        sizePolicy8.setHeightForWidth(user_combo_box->sizePolicy().hasHeightForWidth());
        user_combo_box->setSizePolicy(sizePolicy8);
        user_combo_box->setMinimumSize(QSize(200, 30));

        verticalLayout_21->addWidget(user_combo_box);

        verticalSpacer_5 = new QSpacerItem(200, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

        verticalLayout_21->addItem(verticalSpacer_5);

        verticalSpacer_20 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_21->addItem(verticalSpacer_20);


        horizontalLayout_23->addWidget(user_select_block);

        user_table_view = new QTableView(user_list_block);
        user_table_view->setObjectName(QString::fromUtf8("user_table_view"));
        sizePolicy5.setHeightForWidth(user_table_view->sizePolicy().hasHeightForWidth());
        user_table_view->setSizePolicy(sizePolicy5);

        horizontalLayout_23->addWidget(user_table_view);


        verticalLayout_26->addWidget(user_list_block);


        horizontalLayout_10->addWidget(frame_2);

        setting_stack->addWidget(user_setting);
        category_setting = new QWidget();
        category_setting->setObjectName(QString::fromUtf8("category_setting"));
        horizontalLayout_11 = new QHBoxLayout(category_setting);
        horizontalLayout_11->setObjectName(QString::fromUtf8("horizontalLayout_11"));
        frame_14 = new QFrame(category_setting);
        frame_14->setObjectName(QString::fromUtf8("frame_14"));
        sizePolicy7.setHeightForWidth(frame_14->sizePolicy().hasHeightForWidth());
        frame_14->setSizePolicy(sizePolicy7);
        frame_14->setFrameShape(QFrame::StyledPanel);
        frame_14->setFrameShadow(QFrame::Raised);
        verticalLayout_34 = new QVBoxLayout(frame_14);
        verticalLayout_34->setObjectName(QString::fromUtf8("verticalLayout_34"));
        verticalLayout_34->setContentsMargins(0, 0, 0, 0);
        frame_15 = new QFrame(frame_14);
        frame_15->setObjectName(QString::fromUtf8("frame_15"));
        sizePolicy8.setHeightForWidth(frame_15->sizePolicy().hasHeightForWidth());
        frame_15->setSizePolicy(sizePolicy8);
        frame_15->setStyleSheet(QString::fromUtf8("QFrame\n"
"{\n"
"	background: #ADE2FF;\n"
"	border-radius: 15px;\n"
"}"));
        frame_15->setFrameShape(QFrame::StyledPanel);
        frame_15->setFrameShadow(QFrame::Raised);
        horizontalLayout_15 = new QHBoxLayout(frame_15);
        horizontalLayout_15->setObjectName(QString::fromUtf8("horizontalLayout_15"));
        label_11 = new QLabel(frame_15);
        label_11->setObjectName(QString::fromUtf8("label_11"));
        sizePolicy9.setHeightForWidth(label_11->sizePolicy().hasHeightForWidth());
        label_11->setSizePolicy(sizePolicy9);

        horizontalLayout_15->addWidget(label_11);

        horizontalSpacer_2 = new QSpacerItem(400, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

        horizontalLayout_15->addItem(horizontalSpacer_2);


        verticalLayout_34->addWidget(frame_15);

        frame_16 = new QFrame(frame_14);
        frame_16->setObjectName(QString::fromUtf8("frame_16"));
        sizePolicy5.setHeightForWidth(frame_16->sizePolicy().hasHeightForWidth());
        frame_16->setSizePolicy(sizePolicy5);
        frame_16->setFrameShape(QFrame::StyledPanel);
        frame_16->setFrameShadow(QFrame::Raised);
        verticalLayout_35 = new QVBoxLayout(frame_16);
        verticalLayout_35->setObjectName(QString::fromUtf8("verticalLayout_35"));
        verticalLayout_35->setContentsMargins(0, -1, -1, -1);
        verticalSpacer_12 = new QSpacerItem(20, 10, QSizePolicy::Minimum, QSizePolicy::Fixed);

        verticalLayout_35->addItem(verticalSpacer_12);

        verticalLayout_37 = new QVBoxLayout();
        verticalLayout_37->setSpacing(0);
        verticalLayout_37->setObjectName(QString::fromUtf8("verticalLayout_37"));
        label_12 = new QLabel(frame_16);
        label_12->setObjectName(QString::fromUtf8("label_12"));
        sizePolicy10.setHeightForWidth(label_12->sizePolicy().hasHeightForWidth());
        label_12->setSizePolicy(sizePolicy10);

        verticalLayout_37->addWidget(label_12, 0, Qt::AlignTop);

        lineEdit_5 = new QLineEdit(frame_16);
        lineEdit_5->setObjectName(QString::fromUtf8("lineEdit_5"));
        sizePolicy11.setHeightForWidth(lineEdit_5->sizePolicy().hasHeightForWidth());
        lineEdit_5->setSizePolicy(sizePolicy11);
        lineEdit_5->setStyleSheet(QString::fromUtf8("	border-top-right-radius: 10px;\n"
"	border-top-left-radius:10px;\n"
"	border-bottom-right-radius: 10px;\n"
"	border-bottom-left-radius:10px;"));

        verticalLayout_37->addWidget(lineEdit_5);


        verticalLayout_35->addLayout(verticalLayout_37);

        verticalSpacer_11 = new QSpacerItem(20, 20, QSizePolicy::Minimum, QSizePolicy::Fixed);

        verticalLayout_35->addItem(verticalSpacer_11);

        verticalLayout_38 = new QVBoxLayout();
        verticalLayout_38->setSpacing(0);
        verticalLayout_38->setObjectName(QString::fromUtf8("verticalLayout_38"));
        label_13 = new QLabel(frame_16);
        label_13->setObjectName(QString::fromUtf8("label_13"));
        sizePolicy10.setHeightForWidth(label_13->sizePolicy().hasHeightForWidth());
        label_13->setSizePolicy(sizePolicy10);

        verticalLayout_38->addWidget(label_13, 0, Qt::AlignTop);

        lineEdit_6 = new QLineEdit(frame_16);
        lineEdit_6->setObjectName(QString::fromUtf8("lineEdit_6"));
        lineEdit_6->setStyleSheet(QString::fromUtf8("	border-top-right-radius: 10px;\n"
"	border-top-left-radius:10px;\n"
"	border-bottom-right-radius: 10px;\n"
"	border-bottom-left-radius:10px;"));

        verticalLayout_38->addWidget(lineEdit_6);


        verticalLayout_35->addLayout(verticalLayout_38);

        verticalSpacer_14 = new QSpacerItem(20, 20, QSizePolicy::Minimum, QSizePolicy::Fixed);

        verticalLayout_35->addItem(verticalSpacer_14);

        frame_5 = new QFrame(frame_16);
        frame_5->setObjectName(QString::fromUtf8("frame_5"));
        frame_5->setFrameShape(QFrame::StyledPanel);
        frame_5->setFrameShadow(QFrame::Raised);
        horizontalLayout_24 = new QHBoxLayout(frame_5);
        horizontalLayout_24->setObjectName(QString::fromUtf8("horizontalLayout_24"));
        pushButton_6 = new QPushButton(frame_5);
        pushButton_6->setObjectName(QString::fromUtf8("pushButton_6"));
        pushButton_6->setFont(font);

        horizontalLayout_24->addWidget(pushButton_6);

        pushButton_7 = new QPushButton(frame_5);
        pushButton_7->setObjectName(QString::fromUtf8("pushButton_7"));

        horizontalLayout_24->addWidget(pushButton_7);


        verticalLayout_35->addWidget(frame_5);

        verticalSpacer_15 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_35->addItem(verticalSpacer_15);


        verticalLayout_34->addWidget(frame_16);

        frame_18 = new QFrame(frame_14);
        frame_18->setObjectName(QString::fromUtf8("frame_18"));
        sizePolicy6.setHeightForWidth(frame_18->sizePolicy().hasHeightForWidth());
        frame_18->setSizePolicy(sizePolicy6);
        frame_18->setFrameShape(QFrame::StyledPanel);
        frame_18->setFrameShadow(QFrame::Raised);
        verticalLayout_41 = new QVBoxLayout(frame_18);
        verticalLayout_41->setObjectName(QString::fromUtf8("verticalLayout_41"));
        verticalLayout_41->setContentsMargins(0, -1, -1, -1);

        verticalLayout_34->addWidget(frame_18);


        horizontalLayout_11->addWidget(frame_14);

        frame_8 = new QFrame(category_setting);
        frame_8->setObjectName(QString::fromUtf8("frame_8"));
        frame_8->setFrameShape(QFrame::StyledPanel);
        frame_8->setFrameShadow(QFrame::Raised);
        verticalLayout_31 = new QVBoxLayout(frame_8);
        verticalLayout_31->setObjectName(QString::fromUtf8("verticalLayout_31"));
        verticalLayout_31->setContentsMargins(0, 0, 0, 0);
        frame_13 = new QFrame(frame_8);
        frame_13->setObjectName(QString::fromUtf8("frame_13"));
        frame_13->setStyleSheet(QString::fromUtf8("QFrame\n"
"{\n"
"	background: #ADE2FF;\n"
"	border-radius: 15px;\n"
"}"));
        frame_13->setFrameShape(QFrame::StyledPanel);
        frame_13->setFrameShadow(QFrame::Raised);
        verticalLayout_33 = new QVBoxLayout(frame_13);
        verticalLayout_33->setObjectName(QString::fromUtf8("verticalLayout_33"));
        label_10 = new QLabel(frame_13);
        label_10->setObjectName(QString::fromUtf8("label_10"));

        verticalLayout_33->addWidget(label_10);


        verticalLayout_31->addWidget(frame_13);

        category_table_view = new QTableView(frame_8);
        category_table_view->setObjectName(QString::fromUtf8("category_table_view"));
        sizePolicy12.setHeightForWidth(category_table_view->sizePolicy().hasHeightForWidth());
        category_table_view->setSizePolicy(sizePolicy12);

        verticalLayout_31->addWidget(category_table_view);


        horizontalLayout_11->addWidget(frame_8);

        setting_stack->addWidget(category_setting);

        verticalLayout_43->addWidget(setting_stack);


        verticalLayout_36->addWidget(setting_block);

        setting_button_block = new QFrame(setting_panel);
        setting_button_block->setObjectName(QString::fromUtf8("setting_button_block"));
        setting_button_block->setMinimumSize(QSize(0, 80));
        setting_button_block->setMaximumSize(QSize(16777215, 80));
        setting_button_block->setFrameShape(QFrame::StyledPanel);
        setting_button_block->setFrameShadow(QFrame::Raised);
        horizontalLayout_26 = new QHBoxLayout(setting_button_block);
        horizontalLayout_26->setObjectName(QString::fromUtf8("horizontalLayout_26"));
        user_button = new QPushButton(setting_button_block);
        user_button->setObjectName(QString::fromUtf8("user_button"));

        horizontalLayout_26->addWidget(user_button);

        category_button = new QPushButton(setting_button_block);
        category_button->setObjectName(QString::fromUtf8("category_button"));

        horizontalLayout_26->addWidget(category_button);


        verticalLayout_36->addWidget(setting_button_block);


        gridLayout_3->addWidget(setting_panel, 0, 0, 1, 1);

        ui_stack->addWidget(setting_ui);

        verticalLayout_18->addWidget(ui_stack);


        horizontalLayout->addWidget(ui_panel);

        MainWin->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWin);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 1920, 20));
        MainWin->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWin);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        MainWin->setStatusBar(statusbar);

        retranslateUi(MainWin);

        m_button->setDefault(false);
        plot_stack->setCurrentIndex(0);
        e_plot_stack->setCurrentIndex(3);


        QMetaObject::connectSlotsByName(MainWin);
    } // setupUi

    void retranslateUi(QMainWindow *MainWin)
    {
        MainWin->setWindowTitle(QCoreApplication::translate("MainWin", "MainWindow", nullptr));
        logo->setText(QString());
        app_name->setText(QCoreApplication::translate("MainWin", "<h1>Aha</h1>", nullptr));
        workforce_button->setText(QCoreApplication::translate("MainWin", "Workforce", nullptr));
        employee_button->setText(QCoreApplication::translate("MainWin", "Employee", nullptr));
        website_button->setText(QCoreApplication::translate("MainWin", "Website", nullptr));
        setting_button->setText(QCoreApplication::translate("MainWin", "Setting", nullptr));
        credit_label->setText(QCoreApplication::translate("MainWin", "Created by Team 1", nullptr));
        m_button->setText(QString());
        menu_label->setText(QCoreApplication::translate("MainWin", "<h3>Menu</h3>", nullptr));
        ui_title->setText(QCoreApplication::translate("MainWin", "<h1>Workforce</h1>", nullptr));
        category_label->setText(QCoreApplication::translate("MainWin", "Site Category", nullptr));
        website_label->setText(QCoreApplication::translate("MainWin", "Website", nullptr));
        start_date_label->setText(QCoreApplication::translate("MainWin", "Start Date", nullptr));
        end_date_label->setText(QCoreApplication::translate("MainWin", "End Date", nullptr));
        employee_label_2->setText(QCoreApplication::translate("MainWin", "Employee", nullptr));
        category_label_2->setText(QCoreApplication::translate("MainWin", "Site Category", nullptr));
        website_label_2->setText(QCoreApplication::translate("MainWin", "Website", nullptr));
        start_date_label_2->setText(QCoreApplication::translate("MainWin", "Start Date", nullptr));
        end_date_label_2->setText(QCoreApplication::translate("MainWin", "End Date", nullptr));
        file_name_label->setText(QCoreApplication::translate("MainWin", "<h3>File Name</h3>", nullptr));
        browse_button->setText(QCoreApplication::translate("MainWin", "Browse", nullptr));
        OK_button->setText(QCoreApplication::translate("MainWin", "OK", nullptr));
        label_8->setText(QCoreApplication::translate("MainWin", "<h2>Assign Category </h2>", nullptr));
        label_9->setText(QCoreApplication::translate("MainWin", "<h3>Domain</h3>", nullptr));
        label_14->setText(QCoreApplication::translate("MainWin", "<h3>Category</h3>", nullptr));
        pushButton_8->setText(QCoreApplication::translate("MainWin", "Save", nullptr));
        label_20->setText(QCoreApplication::translate("MainWin", "<h2>Website List </h2>", nullptr));
        label_21->setText(QCoreApplication::translate("MainWin", "<h2>Add New Category</h2>", nullptr));
        label_22->setText(QCoreApplication::translate("MainWin", "<h3> Name</h3>", nullptr));
        label_23->setText(QCoreApplication::translate("MainWin", "<h3> Description</h3>", nullptr));
        pushButton_10->setText(QCoreApplication::translate("MainWin", "Add New", nullptr));
        label_24->setText(QCoreApplication::translate("MainWin", "<h2> Category User </h2>", nullptr));
        label_25->setText(QCoreApplication::translate("MainWin", "<h3>Name</h3>", nullptr));
        pushButton_11->setText(QCoreApplication::translate("MainWin", "Remove", nullptr));
        label_26->setText(QCoreApplication::translate("MainWin", "<h2>Category List </h2>", nullptr));
        add_new_user_label->setText(QCoreApplication::translate("MainWin", "<h2>Add New User </h2>", nullptr));
        username_label->setText(QCoreApplication::translate("MainWin", "<h3>Username</h3>", nullptr));
        password_label->setText(QCoreApplication::translate("MainWin", "<h3>Password</h3>", nullptr));
        real_name_label->setText(QCoreApplication::translate("MainWin", "<h3>Name</h3>", nullptr));
        admin_label->setText(QCoreApplication::translate("MainWin", "<h3>Admin</h3>", nullptr));
        supervisor_label->setText(QCoreApplication::translate("MainWin", "<h3>Supervisor</h3>", nullptr));
        admin_check_box->setText(QString());
        supervisor_check_box->setText(QString());
        user_save_button->setText(QCoreApplication::translate("MainWin", "Save", nullptr));
        user_update_button->setText(QCoreApplication::translate("MainWin", "Update", nullptr));
        user_remove_button->setText(QCoreApplication::translate("MainWin", "Remove", nullptr));
        user_list_label->setText(QCoreApplication::translate("MainWin", "<h2>User List </h2>", nullptr));
        label_11->setText(QCoreApplication::translate("MainWin", "<h2>Add New Category</h2>", nullptr));
        label_12->setText(QCoreApplication::translate("MainWin", "<h3> Name</h3>", nullptr));
        label_13->setText(QCoreApplication::translate("MainWin", "<h3> Description</h3>", nullptr));
        pushButton_6->setText(QCoreApplication::translate("MainWin", "Add New", nullptr));
        pushButton_7->setText(QCoreApplication::translate("MainWin", "Remove", nullptr));
        label_10->setText(QCoreApplication::translate("MainWin", "<h2>Category List </h2>", nullptr));
        user_button->setText(QCoreApplication::translate("MainWin", "User", nullptr));
        category_button->setText(QCoreApplication::translate("MainWin", "Category", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWin: public Ui_MainWin {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWIN_H
