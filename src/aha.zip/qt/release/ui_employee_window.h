/********************************************************************************
** Form generated from reading UI file 'employee_window.ui'
**
** Created by: Qt User Interface Compiler version 6.2.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_EMPLOYEE_WINDOW_H
#define UI_EMPLOYEE_WINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QFrame>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_employee_window
{
public:
    QWidget *centralwidget;
    QHBoxLayout *horizontalLayout;
    QFrame *ui_panel;
    QVBoxLayout *verticalLayout_18;
    QFrame *header;
    QHBoxLayout *horizontalLayout_3;
    QFrame *menu_handle;
    QHBoxLayout *horizontalLayout_4;
    QFrame *title_block;
    QVBoxLayout *verticalLayout_12;
    QLabel *ui_title;
    QFrame *navigation;
    QHBoxLayout *horizontalLayout_5;
    QPushButton *hide_button;
    QPushButton *resize_button;
    QPushButton *close_button;
    QFrame *frame_17;
    QLineEdit *file_name_line_edit;
    QLabel *file_name_label;
    QWidget *widget;
    QHBoxLayout *horizontalLayout_2;
    QPushButton *browse_button;
    QSpacerItem *horizontalSpacer;
    QPushButton *OK_button;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QWidget *employee_window)
    {
        if (employee_window->objectName().isEmpty())
            employee_window->setObjectName(QString::fromUtf8("employee_window"));
        employee_window->resize(1920, 1080);
        employee_window->setStyleSheet(QString::fromUtf8("\n"
"\n"
"/*Copyright (c) DevSec Studio. All rights reserved.\n"
"\n"
"MIT License\n"
"\n"
"Permission is hereby granted, free of charge, to any person obtaining a copy\n"
"of this software and associated documentation files (the \"Software\"), to deal\n"
"in the Software without restriction, including without limitation the rights\n"
"to use, copy, modify, merge, publish, distribute, sublicense, and/or sell\n"
"copies of the Software, and to permit persons to whom the Software is\n"
"furnished to do so, subject to the following conditions:\n"
"\n"
"The above copyright notice and this permission notice shall be included in all\n"
"copies or substantial portions of the Software.\n"
"\n"
"THE SOFTWARE IS PROVIDED *AS IS*, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR\n"
"IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,\n"
"FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE\n"
"AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER\n"
"LIABILITY, WHETHER"
                        " IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,\n"
"OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.\n"
"*/\n"
"\n"
"\n"
"/*-----QWidget-----*/\n"
"QWidget\n"
"{\n"
"	background-color: #ffffff;\n"
"	color: #023E8A;\n"
"\n"
"}\n"
"\n"
"\n"
"/*-----QLabel-----*/\n"
"QLabel\n"
"{\n"
"	background-color: transparent;\n"
"	color: #1D3557;\n"
"	font-weight: bold;\n"
"	font-size: 13px;\n"
"\n"
"}\n"
"\n"
"\n"
"/*-----QPushButton-----*/\n"
"QPushButton\n"
"{\n"
"	background-color: #0077B6;\n"
"	color: #fff;\n"
"	font-size: 13px;\n"
"	font-weight: bold;\n"
"	border-top-right-radius: 15px;\n"
"	border-top-left-radius: 15px;\n"
"	border-bottom-right-radius: 15px;\n"
"	border-bottom-left-radius: 15px;\n"
"	padding: 10px;\n"
"\n"
"}\n"
"\n"
"\n"
"QPushButton::disabled\n"
"{\n"
"	background-color: #5c5c5c;\n"
"\n"
"}\n"
"\n"
"\n"
"QPushButton::hover\n"
"{\n"
"	background-color: #00B4D8;\n"
"\n"
"}\n"
"\n"
"\n"
"QPushButton::pressed\n"
"{\n"
"	background-color: #023E8A;\n"
"\n"
""
                        "}\n"
"\n"
"\n"
"/*-----QCheckBox-----*/\n"
"QCheckBox\n"
"{\n"
"	background-color: transparent;\n"
"	color: #0077B6;\n"
"	font-size: 10px;\n"
"	font-weight: bold;\n"
"	border: none;\n"
"	border-radius: 5px;\n"
"\n"
"}\n"
"\n"
"\n"
"/*-----QCheckBox-----*/\n"
"QCheckBox::indicator\n"
"{\n"
"    background-color: #323232;\n"
"    border: 1px solid darkgray;\n"
"    width: 12px;\n"
"    height: 12px;\n"
"\n"
"}\n"
"\n"
"\n"
"QCheckBox::indicator:checked\n"
"{\n"
"    image:url(\"./ressources/check.png\");\n"
"	background-color: #0077B6;\n"
"    border: 1px solid #0077B6;\n"
"\n"
"}\n"
"\n"
"\n"
"QCheckBox::indicator:unchecked:hover\n"
"{\n"
"    border: 1px solid #0077B6;\n"
"\n"
"}\n"
"\n"
"\n"
"QCheckBox::disabled\n"
"{\n"
"	color: #656565;\n"
"\n"
"}\n"
"\n"
"\n"
"QCheckBox::indicator:disabled\n"
"{\n"
"	background-color: #656565;\n"
"	color: #656565;\n"
"    border: 1px solid #656565;\n"
"\n"
"}\n"
"\n"
"\n"
"/*-----QLineEdit-----*/\n"
"QLineEdit\n"
"{\n"
"	background-color: #c2c7d5;\n"
"	color: #2a547f;\n"
""
                        "	border: none;\n"
"	padding: 5px;\n"
"\n"
"}\n"
"\n"
"\n"
"/*-----QListView-----*/\n"
"QListView\n"
"{\n"
"	background-color: #0077B6;\n"
"	color: #000000;\n"
"	font-size: 14px;\n"
"	font-weight: bold;\n"
"	show-decoration-selected: 0;\n"
"	border-radius: 4px;\n"
"	padding-left: -15px;\n"
"	padding-right: -15px;\n"
"	padding-top: 5px;\n"
"\n"
"} \n"
"\n"
"\n"
"QListView:disabled \n"
"{\n"
"	background-color: #5c5c5c;\n"
"\n"
"}\n"
"\n"
"\n"
"QListView::item\n"
"{\n"
"	background-color: #454e5e;\n"
"	border: none;\n"
"	padding: 10px;\n"
"	border-radius: 0px;\n"
"	padding-left : 10px;\n"
"	height: 32px;\n"
"\n"
"}\n"
"\n"
"\n"
"QListView::item:selected\n"
"{\n"
"	color: #000;\n"
"	background-color: #fff;\n"
"\n"
"}\n"
"\n"
"\n"
"QListView::item:!selected\n"
"{\n"
"	color:#000000;\n"
"	background-color: transparent;\n"
"	border: none;\n"
"	padding-left : 10px;\n"
"\n"
"}\n"
"\n"
"\n"
"QListView::item:!selected:hover\n"
"{\n"
"	color: #000000f;\n"
"	background-color: #00B4D8;\n"
"	border: none;\n"
"	padding-left :"
                        " 10px;\n"
"\n"
"}\n"
"\n"
"\n"
"/*-----QTreeView-----*/\n"
"QTreeView \n"
"{\n"
"	background-color: #fff;\n"
"	show-decoration-selected: 0;\n"
"	color: #1D3557;\n"
"\n"
"}\n"
"\n"
"\n"
"QTreeView:disabled\n"
"{\n"
"	background-color: #242526;\n"
"	show-decoration-selected: 0;\n"
"\n"
"}\n"
"\n"
"\n"
"QTreeView::item \n"
"{\n"
"	border-top-color: transparent;\n"
"	border-bottom-color: transparent;\n"
"\n"
"}\n"
"\n"
"\n"
"QTreeView::item:hover \n"
"{\n"
"	background-color: #bcbdbb;\n"
"	color: #000;\n"
"\n"
"}\n"
"\n"
"\n"
"QTreeView::item:selected \n"
"{\n"
"	background-color: #0077B6;\n"
"	color: #fff;\n"
"\n"
"}\n"
"\n"
"\n"
"QTreeView::item:selected:active\n"
"{\n"
"	background-color: #0077B6;\n"
"	color: #fff;\n"
"\n"
"}\n"
"\n"
"\n"
"QTreeView::item:selected:disabled\n"
"{\n"
"	background-color: #525251;\n"
"	color: #656565;\n"
"\n"
"}\n"
"\n"
"\n"
"QTreeView::branch:has-children:!has-siblings:closed,\n"
"QTreeView::branch:closed:has-children:has-siblings \n"
"{\n"
"	image: url(://tree-closed.png);\n"
"\n"
""
                        "}\n"
"\n"
"QTreeView::branch:open:has-children:!has-siblings,\n"
"QTreeView::branch:open:has-children:has-siblings  \n"
"{\n"
"	image: url(://tree-open.png);\n"
"\n"
"}\n"
"\n"
"\n"
"/*-----QTableView & QTableWidget-----*/\n"
"QTableView\n"
"{\n"
"    background-color: #fff;\n"
"	border: 1px solid gray;\n"
"font-weight: bold;\n"
"    color: #1D3557;\n"
"    gridline-color: gray;\n"
"    outline : 0;\n"
"\n"
"}\n"
"\n"
"\n"
"QTableView::disabled\n"
"{\n"
"    background-color: #242526;\n"
"    border: 1px solid #32414B;\n"
"    color: #656565;\n"
"    gridline-color: #656565;\n"
"    outline : 0;\n"
"\n"
"}\n"
"\n"
"\n"
"QTableView::item:hover \n"
"{\n"
"    background-color: #bcbdbb;\n"
"    color:#000000;\n"
"\n"
"}\n"
"\n"
"\n"
"QTableView::item:selected \n"
"{\n"
"	background-color: #0077B6;\n"
"    color: #000000;\n"
"\n"
"}\n"
"\n"
"\n"
"QTableView::item:selected:disabled\n"
"{\n"
"    background-color: #1a1b1c;\n"
"    border: 2px solid #525251;\n"
"    color: #656565;\n"
"\n"
"}\n"
"\n"
"\n"
"QTableCorn"
                        "erButton::section\n"
"{\n"
"	background-color: #ced5e3;\n"
"	border: none;\n"
"    color:#000000;\n"
"\n"
"}\n"
"\n"
"\n"
"QHeaderView::section\n"
"{\n"
"	color: #2a547f;\n"
"	border: 0px;\n"
"	background-color: #ced5e3;\n"
"	padding: 5px;\n"
"\n"
"}\n"
"\n"
"\n"
"QHeaderView::section:disabled\n"
"{\n"
"    background-color: #525251;\n"
"    color: #656565;\n"
"\n"
"}\n"
"\n"
"\n"
"QHeaderView::section:checked\n"
"{\n"
"    color: #000000;\n"
"    background-color: #0077B6;\n"
"\n"
"}\n"
"\n"
"\n"
"QHeaderView::section:checked:disabled\n"
"{\n"
"    color: #656565;\n"
"    background-color: #525251;\n"
"\n"
"}\n"
"\n"
"\n"
"QHeaderView::section::vertical::first,\n"
"QHeaderView::section::vertical::only-one\n"
"{\n"
"    border-top: 1px solid #353635;\n"
"\n"
"}\n"
"\n"
"\n"
"QHeaderView::section::vertical\n"
"{\n"
"    border-top: 1px solid #353635;\n"
"\n"
"}\n"
"\n"
"\n"
"QHeaderView::section::horizontal::first,\n"
"QHeaderView::section::horizontal::only-one\n"
"{\n"
"    border-left: 1px solid #353635;\n"
""
                        "\n"
"}\n"
"\n"
"\n"
"QHeaderView::section::horizontal\n"
"{\n"
"    border-left: 1px solid #353635;\n"
"\n"
"}\n"
"\n"
"\n"
"/*-----QScrollBar-----*/\n"
"QScrollBar:horizontal \n"
"{\n"
"    background-color: transparent;\n"
"    height: 8px;\n"
"    margin: 0px;\n"
"    padding: 0px;\n"
"\n"
"}\n"
"\n"
"\n"
"QScrollBar::handle:horizontal \n"
"{\n"
"    border: none;\n"
"	min-width: 100px;\n"
"    background-color: #7e92b7;\n"
"\n"
"}\n"
"\n"
"\n"
"QScrollBar::add-line:horizontal, \n"
"QScrollBar::sub-line:horizontal,\n"
"QScrollBar::add-page:horizontal, \n"
"QScrollBar::sub-page:horizontal \n"
"{\n"
"    width: 0px;\n"
"    background-color: #d8dce6;\n"
"\n"
"}\n"
"\n"
"\n"
"QScrollBar:vertical \n"
"{\n"
"    background-color: transparent;\n"
"    width: 8px;\n"
"    margin: 0;\n"
"\n"
"}\n"
"\n"
"\n"
"QScrollBar::handle:vertical \n"
"{\n"
"    border: none;\n"
"	min-height: 100px;\n"
"    background-color: #7e92b7;\n"
"\n"
"}\n"
"\n"
"\n"
"QScrollBar::add-line:vertical, \n"
"QScrollBar::sub-line:vertical,\n"
""
                        "QScrollBar::add-page:vertical, \n"
"QScrollBar::sub-page:vertical \n"
"{\n"
"    height: 0px;\n"
"    background-color: #d8dce6;\n"
"\n"
"}\n"
""));
        centralwidget = new QWidget(employee_window);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        horizontalLayout = new QHBoxLayout(centralwidget);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        ui_panel = new QFrame(centralwidget);
        ui_panel->setObjectName(QString::fromUtf8("ui_panel"));
        ui_panel->setStyleSheet(QString::fromUtf8("border-radius: 15px;"));
        ui_panel->setFrameShape(QFrame::StyledPanel);
        ui_panel->setFrameShadow(QFrame::Raised);
        verticalLayout_18 = new QVBoxLayout(ui_panel);
        verticalLayout_18->setSpacing(7);
        verticalLayout_18->setObjectName(QString::fromUtf8("verticalLayout_18"));
        verticalLayout_18->setContentsMargins(0, 0, 0, 0);
        header = new QFrame(ui_panel);
        header->setObjectName(QString::fromUtf8("header"));
        header->setMinimumSize(QSize(0, 80));
        header->setMaximumSize(QSize(16777215, 70));
        header->setStyleSheet(QString::fromUtf8("QFrame\n"
"{\n"
"	background: #0092E0;\n"
"\n"
"}"));
        header->setFrameShape(QFrame::StyledPanel);
        header->setFrameShadow(QFrame::Raised);
        horizontalLayout_3 = new QHBoxLayout(header);
        horizontalLayout_3->setSpacing(0);
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        horizontalLayout_3->setContentsMargins(0, 0, 0, 0);
        menu_handle = new QFrame(header);
        menu_handle->setObjectName(QString::fromUtf8("menu_handle"));
        menu_handle->setMinimumSize(QSize(150, 0));
        menu_handle->setMaximumSize(QSize(40, 16777215));
        menu_handle->setFrameShape(QFrame::StyledPanel);
        menu_handle->setFrameShadow(QFrame::Raised);
        horizontalLayout_4 = new QHBoxLayout(menu_handle);
        horizontalLayout_4->setSpacing(7);
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        horizontalLayout_4->setContentsMargins(11, 11, 11, 11);

        horizontalLayout_3->addWidget(menu_handle);

        title_block = new QFrame(header);
        title_block->setObjectName(QString::fromUtf8("title_block"));
        title_block->setFrameShape(QFrame::StyledPanel);
        title_block->setFrameShadow(QFrame::Raised);
        verticalLayout_12 = new QVBoxLayout(title_block);
        verticalLayout_12->setSpacing(0);
        verticalLayout_12->setObjectName(QString::fromUtf8("verticalLayout_12"));
        verticalLayout_12->setContentsMargins(0, 0, 0, 0);
        ui_title = new QLabel(title_block);
        ui_title->setObjectName(QString::fromUtf8("ui_title"));
        ui_title->setAlignment(Qt::AlignCenter);

        verticalLayout_12->addWidget(ui_title);


        horizontalLayout_3->addWidget(title_block);

        navigation = new QFrame(header);
        navigation->setObjectName(QString::fromUtf8("navigation"));
        navigation->setMinimumSize(QSize(150, 0));
        navigation->setMaximumSize(QSize(150, 16777215));
        navigation->setFrameShape(QFrame::StyledPanel);
        navigation->setFrameShadow(QFrame::Raised);
        horizontalLayout_5 = new QHBoxLayout(navigation);
        horizontalLayout_5->setSpacing(0);
        horizontalLayout_5->setObjectName(QString::fromUtf8("horizontalLayout_5"));
        horizontalLayout_5->setContentsMargins(0, 0, 0, 0);
        hide_button = new QPushButton(navigation);
        hide_button->setObjectName(QString::fromUtf8("hide_button"));
        hide_button->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"	background-color: transparent;\n"
"}\n"
"\n"
"QPushButton::hover\n"
"{\n"
"	background-color: #CAF0F8;\n"
"}\n"
""));
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/picture/picture/hide.png"), QSize(), QIcon::Normal, QIcon::Off);
        hide_button->setIcon(icon);
        hide_button->setIconSize(QSize(30, 30));

        horizontalLayout_5->addWidget(hide_button);

        resize_button = new QPushButton(navigation);
        resize_button->setObjectName(QString::fromUtf8("resize_button"));
        resize_button->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"	background-color: transparent;\n"
"}\n"
"\n"
"QPushButton::hover\n"
"{\n"
"	background-color: #CAF0F8;\n"
"}\n"
""));
        QIcon icon1;
        icon1.addFile(QString::fromUtf8(":/picture/picture/resize.png"), QSize(), QIcon::Normal, QIcon::Off);
        resize_button->setIcon(icon1);
        resize_button->setIconSize(QSize(30, 30));
        resize_button->setCheckable(true);

        horizontalLayout_5->addWidget(resize_button);

        close_button = new QPushButton(navigation);
        close_button->setObjectName(QString::fromUtf8("close_button"));
        close_button->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"	background-color: transparent;\n"
"}\n"
"\n"
"QPushButton::hover\n"
"{\n"
"	background-color: #CAF0F8;\n"
"}\n"
""));
        QIcon icon2;
        icon2.addFile(QString::fromUtf8(":/picture/picture/close.png"), QSize(), QIcon::Normal, QIcon::Off);
        close_button->setIcon(icon2);
        close_button->setIconSize(QSize(30, 30));

        horizontalLayout_5->addWidget(close_button);


        horizontalLayout_3->addWidget(navigation);


        verticalLayout_18->addWidget(header, 0, Qt::AlignTop);

        frame_17 = new QFrame(ui_panel);
        frame_17->setObjectName(QString::fromUtf8("frame_17"));
        QSizePolicy sizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(frame_17->sizePolicy().hasHeightForWidth());
        frame_17->setSizePolicy(sizePolicy);
        frame_17->setFrameShape(QFrame::StyledPanel);
        frame_17->setFrameShadow(QFrame::Raised);
        file_name_line_edit = new QLineEdit(frame_17);
        file_name_line_edit->setObjectName(QString::fromUtf8("file_name_line_edit"));
        file_name_line_edit->setGeometry(QRect(490, 330, 911, 31));
        file_name_label = new QLabel(frame_17);
        file_name_label->setObjectName(QString::fromUtf8("file_name_label"));
        file_name_label->setGeometry(QRect(490, 296, 81, 19));
        widget = new QWidget(frame_17);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setGeometry(QRect(730, 436, 421, 38));
        horizontalLayout_2 = new QHBoxLayout(widget);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        horizontalLayout_2->setContentsMargins(0, 0, 0, 0);
        browse_button = new QPushButton(widget);
        browse_button->setObjectName(QString::fromUtf8("browse_button"));

        horizontalLayout_2->addWidget(browse_button);

        horizontalSpacer = new QSpacerItem(60, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer);

        OK_button = new QPushButton(widget);
        OK_button->setObjectName(QString::fromUtf8("OK_button"));

        horizontalLayout_2->addWidget(OK_button);


        verticalLayout_18->addWidget(frame_17);


        horizontalLayout->addWidget(ui_panel);

        menubar = new QMenuBar(employee_window);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 1920, 20));
        statusbar = new QStatusBar(employee_window);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));

        retranslateUi(employee_window);

        QMetaObject::connectSlotsByName(employee_window);
    } // setupUi

    void retranslateUi(QWidget *employee_window)
    {
        employee_window->setWindowTitle(QCoreApplication::translate("employee_window", "MainWindow", nullptr));
        ui_title->setText(QCoreApplication::translate("employee_window", "<h1>Dashboard</h1>", nullptr));
        file_name_label->setText(QCoreApplication::translate("employee_window", "<h3>File Name</h3>", nullptr));
        browse_button->setText(QCoreApplication::translate("employee_window", "Browse", nullptr));
        OK_button->setText(QCoreApplication::translate("employee_window", "OK", nullptr));
    } // retranslateUi

};

namespace Ui {
    class employee_window: public Ui_employee_window {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_EMPLOYEE_WINDOW_H
