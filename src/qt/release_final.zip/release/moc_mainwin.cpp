/****************************************************************************
** Meta object code from reading C++ file 'mainwin.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.2.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../aha/mainwin.h"
#include <QtGui/qtextcursor.h>
#include <QScreen>
#include <QtCharts/qlineseries.h>
#include <QtCharts/qabstractbarseries.h>
#include <QtCharts/qvbarmodelmapper.h>
#include <QtCharts/qboxplotseries.h>
#include <QtCharts/qcandlestickseries.h>
#include <QtCore/qabstractitemmodel.h>
#include <QtCharts/qpieseries.h>
#include <QtCore/qabstractitemmodel.h>
#include <QtCharts/qboxplotseries.h>
#include <QtCore/qabstractitemmodel.h>
#include <QtCharts/qpieseries.h>
#include <QtCharts/qpieseries.h>
#include <QtCore/qabstractitemmodel.h>
#include <QtCharts/qxyseries.h>
#include <QtCharts/qxyseries.h>
#include <QtCore/qabstractitemmodel.h>
#include <QtCore/qabstractitemmodel.h>
#include <QtCharts/qboxplotseries.h>
#include <QtCore/qabstractitemmodel.h>
#include <QtCharts/qpieseries.h>
#include <QtCore/qabstractitemmodel.h>
#include <QtCharts/qxyseries.h>
#include <QtCore/qabstractitemmodel.h>
#include <QtNetwork/QSslError>
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwin.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.2.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MainWin_t {
    const uint offsetsAndSize[74];
    char stringdata0[880];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(offsetof(qt_meta_stringdata_MainWin_t, stringdata0) + ofs), len 
static const qt_meta_stringdata_MainWin_t qt_meta_stringdata_MainWin = {
    {
QT_MOC_LITERAL(0, 7), // "MainWin"
QT_MOC_LITERAL(8, 19), // "on_m_button_clicked"
QT_MOC_LITERAL(28, 0), // ""
QT_MOC_LITERAL(29, 27), // "on_bar_chart_button_clicked"
QT_MOC_LITERAL(57, 27), // "on_pie_chart_button_clicked"
QT_MOC_LITERAL(85, 28), // "on_line_chart_button_clicked"
QT_MOC_LITERAL(114, 27), // "on_workforce_button_clicked"
QT_MOC_LITERAL(142, 26), // "on_employee_button_clicked"
QT_MOC_LITERAL(169, 25), // "on_website_button_clicked"
QT_MOC_LITERAL(195, 25), // "on_setting_button_clicked"
QT_MOC_LITERAL(221, 22), // "on_hide_button_clicked"
QT_MOC_LITERAL(244, 23), // "on_close_button_clicked"
QT_MOC_LITERAL(268, 24), // "on_resize_button_clicked"
QT_MOC_LITERAL(293, 7), // "checked"
QT_MOC_LITERAL(301, 26), // "on_database_button_clicked"
QT_MOC_LITERAL(328, 22), // "on_user_button_clicked"
QT_MOC_LITERAL(351, 26), // "on_category_button_clicked"
QT_MOC_LITERAL(378, 27), // "on_user_save_button_clicked"
QT_MOC_LITERAL(406, 29), // "on_user_update_button_clicked"
QT_MOC_LITERAL(436, 29), // "on_user_remove_button_clicked"
QT_MOC_LITERAL(466, 36), // "on_user_combo_box_currentText..."
QT_MOC_LITERAL(503, 4), // "arg1"
QT_MOC_LITERAL(508, 11), // "handleLogin"
QT_MOC_LITERAL(520, 4), // "user"
QT_MOC_LITERAL(525, 40), // "on_employee_combo_box_current..."
QT_MOC_LITERAL(566, 40), // "on_category_combo_box_current..."
QT_MOC_LITERAL(607, 3), // "cat"
QT_MOC_LITERAL(611, 29), // "on_e_bar_chart_button_clicked"
QT_MOC_LITERAL(641, 30), // "on_e_line_chart_button_clicked"
QT_MOC_LITERAL(672, 29), // "on_e_pie_chart_button_clicked"
QT_MOC_LITERAL(702, 24), // "on_upload_button_clicked"
QT_MOC_LITERAL(727, 24), // "on_browse_button_clicked"
QT_MOC_LITERAL(752, 20), // "on_OK_button_clicked"
QT_MOC_LITERAL(773, 24), // "on_w_save_button_clicked"
QT_MOC_LITERAL(798, 26), // "on_w_remove_button_clicked"
QT_MOC_LITERAL(825, 27), // "on_c_add_new_button_clicked"
QT_MOC_LITERAL(853, 26) // "on_c_remove_button_clicked"

    },
    "MainWin\0on_m_button_clicked\0\0"
    "on_bar_chart_button_clicked\0"
    "on_pie_chart_button_clicked\0"
    "on_line_chart_button_clicked\0"
    "on_workforce_button_clicked\0"
    "on_employee_button_clicked\0"
    "on_website_button_clicked\0"
    "on_setting_button_clicked\0"
    "on_hide_button_clicked\0on_close_button_clicked\0"
    "on_resize_button_clicked\0checked\0"
    "on_database_button_clicked\0"
    "on_user_button_clicked\0"
    "on_category_button_clicked\0"
    "on_user_save_button_clicked\0"
    "on_user_update_button_clicked\0"
    "on_user_remove_button_clicked\0"
    "on_user_combo_box_currentTextChanged\0"
    "arg1\0handleLogin\0user\0"
    "on_employee_combo_box_currentTextChanged\0"
    "on_category_combo_box_currentTextChanged\0"
    "cat\0on_e_bar_chart_button_clicked\0"
    "on_e_line_chart_button_clicked\0"
    "on_e_pie_chart_button_clicked\0"
    "on_upload_button_clicked\0"
    "on_browse_button_clicked\0on_OK_button_clicked\0"
    "on_w_save_button_clicked\0"
    "on_w_remove_button_clicked\0"
    "on_c_add_new_button_clicked\0"
    "on_c_remove_button_clicked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWin[] = {

 // content:
      10,       // revision
       0,       // classname
       0,    0, // classinfo
      31,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,  200,    2, 0x08,    1 /* Private */,
       3,    0,  201,    2, 0x08,    2 /* Private */,
       4,    0,  202,    2, 0x08,    3 /* Private */,
       5,    0,  203,    2, 0x08,    4 /* Private */,
       6,    0,  204,    2, 0x08,    5 /* Private */,
       7,    0,  205,    2, 0x08,    6 /* Private */,
       8,    0,  206,    2, 0x08,    7 /* Private */,
       9,    0,  207,    2, 0x08,    8 /* Private */,
      10,    0,  208,    2, 0x08,    9 /* Private */,
      11,    0,  209,    2, 0x08,   10 /* Private */,
      12,    1,  210,    2, 0x08,   11 /* Private */,
      14,    0,  213,    2, 0x08,   13 /* Private */,
      15,    0,  214,    2, 0x08,   14 /* Private */,
      16,    0,  215,    2, 0x08,   15 /* Private */,
      17,    0,  216,    2, 0x08,   16 /* Private */,
      18,    0,  217,    2, 0x08,   17 /* Private */,
      19,    0,  218,    2, 0x08,   18 /* Private */,
      20,    1,  219,    2, 0x08,   19 /* Private */,
      22,    1,  222,    2, 0x08,   21 /* Private */,
      24,    1,  225,    2, 0x08,   23 /* Private */,
      25,    1,  228,    2, 0x08,   25 /* Private */,
      27,    0,  231,    2, 0x08,   27 /* Private */,
      28,    0,  232,    2, 0x08,   28 /* Private */,
      29,    0,  233,    2, 0x08,   29 /* Private */,
      30,    0,  234,    2, 0x08,   30 /* Private */,
      31,    0,  235,    2, 0x08,   31 /* Private */,
      32,    0,  236,    2, 0x08,   32 /* Private */,
      33,    0,  237,    2, 0x08,   33 /* Private */,
      34,    0,  238,    2, 0x08,   34 /* Private */,
      35,    0,  239,    2, 0x08,   35 /* Private */,
      36,    0,  240,    2, 0x08,   36 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   13,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   21,
    QMetaType::Void, QMetaType::QString,   23,
    QMetaType::Void, QMetaType::QString,   21,
    QMetaType::Void, QMetaType::QString,   26,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void MainWin::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MainWin *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->on_m_button_clicked(); break;
        case 1: _t->on_bar_chart_button_clicked(); break;
        case 2: _t->on_pie_chart_button_clicked(); break;
        case 3: _t->on_line_chart_button_clicked(); break;
        case 4: _t->on_workforce_button_clicked(); break;
        case 5: _t->on_employee_button_clicked(); break;
        case 6: _t->on_website_button_clicked(); break;
        case 7: _t->on_setting_button_clicked(); break;
        case 8: _t->on_hide_button_clicked(); break;
        case 9: _t->on_close_button_clicked(); break;
        case 10: _t->on_resize_button_clicked((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 11: _t->on_database_button_clicked(); break;
        case 12: _t->on_user_button_clicked(); break;
        case 13: _t->on_category_button_clicked(); break;
        case 14: _t->on_user_save_button_clicked(); break;
        case 15: _t->on_user_update_button_clicked(); break;
        case 16: _t->on_user_remove_button_clicked(); break;
        case 17: _t->on_user_combo_box_currentTextChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 18: _t->handleLogin((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 19: _t->on_employee_combo_box_currentTextChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 20: _t->on_category_combo_box_currentTextChanged((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 21: _t->on_e_bar_chart_button_clicked(); break;
        case 22: _t->on_e_line_chart_button_clicked(); break;
        case 23: _t->on_e_pie_chart_button_clicked(); break;
        case 24: _t->on_upload_button_clicked(); break;
        case 25: _t->on_browse_button_clicked(); break;
        case 26: _t->on_OK_button_clicked(); break;
        case 27: _t->on_w_save_button_clicked(); break;
        case 28: _t->on_w_remove_button_clicked(); break;
        case 29: _t->on_c_add_new_button_clicked(); break;
        case 30: _t->on_c_remove_button_clicked(); break;
        default: ;
        }
    }
}

const QMetaObject MainWin::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_MainWin.offsetsAndSize,
    qt_meta_data_MainWin,
    qt_static_metacall,
    nullptr,
qt_incomplete_metaTypeArray<qt_meta_stringdata_MainWin_t
, QtPrivate::TypeAndForceComplete<MainWin, std::true_type>
, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<bool, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<const QString &, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<QString, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<const QString &, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<QString, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>


>,
    nullptr
} };


const QMetaObject *MainWin::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWin::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MainWin.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWin::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 31)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 31;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 31)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 31;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
