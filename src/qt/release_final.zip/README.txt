Ensure you're connected to the internet
in the release folder, execute aha.exe

to log in as a supervisor:
user - super1
pass - Password123

to log in as an employee:
user - emp1
pass - Password123

Source code is in aha folder
domains.csv is from browser extension, can be uploaded via employee login